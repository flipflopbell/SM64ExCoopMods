smlua_text_utils_dialog_replace(DIALOG_000,1,5,95,200, ("Hello and welcome to \
SUPER MARIO 74: \
TEN YEARS AFTER!\
\
\
This hack is a tribute \
to Lugmillord for creating \
a timeless classic in the\
history of SM64 ROM \
hacking. \
The purpose of this game\
was to merge his hacks \
together and add newer \
themes as if he had made \
a 3rd game in the series.\
Confused? Well, think of \
it as a Banjo-Kazooie\
game created by hardcore\
gamer fans, but you'll \
see what I mean.\
It's meant to celebrate \
the 10 years of the hack\
also. Just sit back and \
enjoy the SM74 nostalgia!"))

smlua_text_utils_dialog_replace(DIALOG_001,1,5,95,200, ("Wow! Look at those \
towers! They are \
downright suspended \
from the sky! \
\
By using [C], the camera \
angles while flying are \
useful to check around\
in case you don't want \
to miss anything.\
Keep that in mind \
when the altitude is \
necessarily slow to\
see what lies ahead."))

smlua_text_utils_dialog_replace(DIALOG_002,1,5,95,200, ("This is the core of \
the gardens. A peaceful\
land that is guarded\
from danger.\
\
First of all, any \
treasure you meet is \
for safekeeping, in no \
way sure to let thieves \
take them away.\
Don't even bother with \
black fences, they are \
so strong that pests like \
you can be repelled.\
\
It would be wise to look \
for a less clear spot \
to get to them, unless\
you are using the camera\
properly."))

smlua_text_utils_dialog_replace(DIALOG_003,1,6,95,200, ("Are you able to see\
anything? Good.\
It may look dim and \
dark but be careful: \
dust is dense than the \
fog. ...Or does it?\
Watch your step, avoid \
traps and falling off\
paths you tread over. \
And most importantly:\
don't fear the darkness."))

smlua_text_utils_dialog_replace(DIALOG_004,1,3,95,200, (""))

smlua_text_utils_dialog_replace(DIALOG_005,1,3,30,200, (""))

smlua_text_utils_dialog_replace(DIALOG_006,1,3,30,200, ("Now now, dude. \
Don't just up and go \
ruin the fun with that \
cannon blast. \
Get out before I break\
my foot off your cheating\
butt to another world!"))

smlua_text_utils_dialog_replace(DIALOG_007,1,4,30,200, (""))

smlua_text_utils_dialog_replace(DIALOG_008,1,5,30,200, ("No frolicking allowed!\
Admiring the flowers\
is all nice and anything \
but the garden is under \
major repair!\
If you fall on something \
unexpected, the damages \
will be returned against\
you. Tread carefully and \
you should be fine."))

smlua_text_utils_dialog_replace(DIALOG_009,1,4,30,200, ("Hi. Remember me?\
We've met in the dead\
swamp before. I've been \
feeling down about it \
since I haven't been able \
to find my brother's \
grave there...\
\
But now, ever since \
Bowser's taken out, I \
find passing the time\
swimming in this reef. \
Say, I'd like to have a \
rematch. Wanna race me? \
The goal is at the star \
platform behind you.\
You good?\
\
//Go//// Not Yet"))

smlua_text_utils_dialog_replace(DIALOG_010,1,4,30,200, ("NOOOO! What did you \
do?! You've literally \
pressed on a dangerous \
red button!!\
You've done it, you have\
caused the world's doom!\
\
\
...\
\
\
\
Well, truth is, you've\
managed to get yourself\
a device to flee from\
your stupidity.\
Save?\
\
//Yes////No"))

smlua_text_utils_dialog_replace(DIALOG_011,1,5,30,200, ("You've activated on\
the green button where\
once was familiar back \
when you were in the\
old caves.\
And would you look at\
that! That uncovered a \
strange box that was\
inside it!\
\
Are you going save\
that discovery?\
\
//Yes////No"))

smlua_text_utils_dialog_replace(DIALOG_012,1,4,30,200, ("Weird... You've pressed \
a blue button and it\
did nothing to lit this\
place up...\
What are you looking\
at? Don't you dare think\
I am responsible of this\
mess, or I won't favor\
you a save!\
\
//Huh?!////Wait!"))

smlua_text_utils_dialog_replace(DIALOG_013,1,5,30,200, ("You earned 100 gold\
coins! A shiny object \
gets to claim your worth.\
Save?\
//Yes////No"))

smlua_text_utils_dialog_replace(DIALOG_014,1,4,30,200, ("Oh wow, another well \
deserved star! I gotta\
be honest: you're so close \
to being a god gamer!\
Are you now proud of\
yourself?\
\
//YEA!////NAY!"))

smlua_text_utils_dialog_replace(DIALOG_015,1,4,30,200, ("Here's a special cap box.\
If you ever come across\
one, remember their\
spot when a star shows\
its label:\
- WC for Wing Cap, \
- MC for Metal Cap,\
- VC for Vanish Cap.\
Only obvious hints \
will tell quicker even \
if you don't follow stars \
in the right order."))

smlua_text_utils_dialog_replace(DIALOG_016,1,3,30,200, ("Whatever you do, don't\
dip in the lava!\
\
...\
\
\
Or do. But you'll melt\
if you keep swimming\
for too long."))

smlua_text_utils_dialog_replace(DIALOG_017,1,4,30,200, ("Guess who's back! I may \
have suffered a crushing\
defeat, but I won't let it \
get to me this time!\
Let's see which of us will \
rule this garden, but this \
ground is all MINE!"))

smlua_text_utils_dialog_replace(DIALOG_018,1,6,30,200, ("This abstract sculpture\
of a pyramid is what has \
become of Tutanpokey's \
reigning downfall.\
His tomb still remains\
deep within the temple. \
Also, there's an invisible\
wall at the bottom that\
I can't get rid of but \
pay it no mind and pass \
it from the sides."))

smlua_text_utils_dialog_replace(DIALOG_019,1,4,30,200, ("Credits goes to:\
\
・ Lugmillord ・ \
Original hack & models\
・ Pilzinsel64 ・ \
SM64 ROM Manager\
・ aglab2 ・ \
Level model rips\
・ FramePerfection ・\
SM64 Collision Patcher\
・ Skelux ・ \
Music ports\
・ SMWCentral ・ \
Music ports & textures\
・ Nintendo ・ \
Original game\
Thanks to:\
Ozsef and DJ Tala \
for playtesting the \
Super Deluxe update.\
Special thanks to:\
To all the Crashers for\
watching me dev the\
ROM hack live.\
Extra thanks to:\
The SM64 RHC Discord\
for reporting all the bugs\
and mistakes.\
Extra special thanks to:\
Ozsef and DJ Tala for\
being real supportive on \
the hotfix update.\
I can't thank both of \
them enough, they helped \
me improve the fixes \
prior to their feedback!\
Honorable shoutouts to:\
aglab2 and ShiN3\
for their exclusive ASM\
codes used in Course 3.\
Extra shoutouts to:\
IwerSonsch, Knuffiilein,\
MariaSnowlily and many\
more favoring this hack!\
And to YOU, the player, \
for believing in me! :)"))

smlua_text_utils_dialog_replace(DIALOG_020,1,6,95,150, (""))

smlua_text_utils_dialog_replace(DIALOG_021,1,5,95,200, ("Hey! You're not supposed\
to be here yet! \
Come back for star 3 \
and you'll be interested \
to see about this cave."))

smlua_text_utils_dialog_replace(DIALOG_022,1,2,95,200, ("Nice try, pal. But this\
door will stay locked."))

smlua_text_utils_dialog_replace(DIALOG_023,1,3,95,200, ("Ha! Ha! Ha!\
You didn't say the\
magic word!"))

smlua_text_utils_dialog_replace(DIALOG_024,1,5,95,200, (""))

smlua_text_utils_dialog_replace(DIALOG_025,1,4,95,200, (""))

smlua_text_utils_dialog_replace(DIALOG_026,1,4,95,200, (""))

smlua_text_utils_dialog_replace(DIALOG_027,1,4,95,200, ("You're still at it, huh?\
Well guess what: this\
door needs another set\
of 30 stars to open.\
So go ahead and waste\
your time to break into\
it cause you're really\
stupid!"))

smlua_text_utils_dialog_replace(DIALOG_028,1,3,95,200, ("Can you just go away? \
Unless maybe you bring \
50 stars, it's fair game. \
However, you don't\
right now. So stop \
bothering that door."))

smlua_text_utils_dialog_replace(DIALOG_029,1,5,95,200, (""))

smlua_text_utils_dialog_replace(DIALOG_030,1,4,30,200, ("Nice view, isn't it? \
We don't get exciting\
sensations around here \
today.\
But if you want, I can\
show you something \
worth the time. Here,\
just stand still on me."))

smlua_text_utils_dialog_replace(DIALOG_031,1,5,30,200, ("Darned I'd be! This is\
a mistake to let those\
wooden floats in the\
way! They made it too\
hard to swim around!\
Here, dude, you deserve \
this star. Come back if \
you want to race me\
some other time."))

smlua_text_utils_dialog_replace(DIALOG_032,1,4,30,200, ("What, you thought by \
I'd leave a star here for \
free? Tsk, how naive.\
\
Now decide your fate:\
Either you stay here \
forever or jump to your \
death."))

smlua_text_utils_dialog_replace(DIALOG_033,1,6,30,200, ("It might look impossible\
at first glance, but if \
you can dash and dive \
rollout hard enough, \
you'll be able to squeeze \
yourself into the tower."))

smlua_text_utils_dialog_replace(DIALOG_034,1,5,30,200, ("What the... \
What are you doing?! \
Your business here is\
over! There's nothing\
left, so now beat it!"))

smlua_text_utils_dialog_replace(DIALOG_035,1,4,30,200, ("Caution! \
Slide under construction!\
Watch out for roadblocks\
or death will occur!"))

smlua_text_utils_dialog_replace(DIALOG_036,1,5,30,200, ("Hey, Mr Plumber. \
If it wasn't for you \
saving the world, this \
door would never have\
been back to life.\
It's proven you've shown \
some respect to them.\
Anyways, this requires \
15 stars to open."))

smlua_text_utils_dialog_replace(DIALOG_037,1,2,30,200, (""))

smlua_text_utils_dialog_replace(DIALOG_038,1,3,95,200, ("You have managed to\
subdue this door using \
the star's powerful shine.\
See? Told you it wasn't \
too hard to carry out\
so many stars!"))

smlua_text_utils_dialog_replace(DIALOG_039,1,5,30,200, ("This looks familiar...\
What ever happened to \
this world to become \
such a wasteland?\
\
Whatever you do, \
DON'T you dare walk \
on the dark matter. \
Who knows if you can't\
come back out...\
Besides, the only way \
you can do to leave this\
nightmare is to grab\
these boxes of old \
memories."))

smlua_text_utils_dialog_replace(DIALOG_040,1,3,30,200, ("Watch out! Don't step\
on the flowerbeds!\
Extremely lethal!\
These dark patches on \
top... Could they even\
mean something?\
In that case, you can \
trust the Metal Cap to \
figure this puzzle!"))

smlua_text_utils_dialog_replace(DIALOG_041,1,3,30,200, ("Yes! I've done it!\
Well too bad, dude,\
this win is on me!\
While my brother's honor \
is not in vain, you can\
try to race me again!"))

smlua_text_utils_dialog_replace(DIALOG_042,1,5,30,200, ("Our little old challenge\
is back, at last!\
You know the drill:\
get to the top, BUT on\
one condition.\
If you can make it in \
less than 21 seconds, \
you will be awarded \
a star and a lot of \
praise."))

smlua_text_utils_dialog_replace(DIALOG_043,1,5,30,200, ("Thought the trial was \
over? How naive.\
This was a warm-up. \
That one is an even \
bigger challenge. \
I would tell you what \
lies in this pipe only if \
you can unlock it by \
collecting 154 stars."))

smlua_text_utils_dialog_replace(DIALOG_044,1,5,95,200, (""))

smlua_text_utils_dialog_replace(DIALOG_045,1,6,95,200, (""))

smlua_text_utils_dialog_replace(DIALOG_046,1,5,30,200, ("Well... to think you \
have unlocked the seal \
means that you're now\
prepared for the true\
challenge.\
Welcome to the \
Grandmaster's Goal:\
a large road of none\
but past worlds you \
have explored before.\
But beware: should you \
fail, and you're back\
to square one. That's \
right. ONE perfect run, \
NO checkpoints.\
You've come a long way\
to get there but I hope\
you will enjoy what we\
have to offer. Good luck,\
grand champion."))

smlua_text_utils_dialog_replace(DIALOG_047,1,2,95,200, ("Bob-omblast Corp. at\
your service!"))

smlua_text_utils_dialog_replace(DIALOG_048,1,3,30,200, ("Hold it! \
If I were you, I wouldn't \
swim in the pond! \
These vile beasts are \
craving for fresh meat, \
so you better watch it.\
Oh well, do what you \
will, I am not responsible \
for your life decisions."))

smlua_text_utils_dialog_replace(DIALOG_049,1,4,30,200, ("Watch out! \
Keep off the green bog \
or you will drown!\
I meant it. Literally!"))

smlua_text_utils_dialog_replace(DIALOG_050,1,5,30,200, ("Uh, hi. I don't know\
how I got here but I'm\
being the only resident\
in this town.\
\
But I've never seen you \
around though, I assume\
you're going to get me \
out of this mansion,\
right? No?\
...Nevermind. I got \
carried away with my \
request and this fence \
is distancing us.\
\
What about this star\
behind me? People are\
tempted to take it other\
than saving a poor sign.\
\
How would you get inside?\
I don't know. But I feel\
you can get in if you\
look a little closer in \
the room..."))

smlua_text_utils_dialog_replace(DIALOG_051,1,4,30,200, ("This box is a reminder\
from super gamers \
being able to pull off a \
capless trick. \
But it's pointless to do\
so, instead, make it up\
to the platform right\
above you.\
If you screw up, you can\
try it again with the\
second crazy box."))

smlua_text_utils_dialog_replace(DIALOG_052,1,5,30,200, ("Yikes! The thwomps \
trapped you in this\
cave and you can't \
get out anymore with\
this river of acid!\
Well, you still can leave, \
but let's face it. There \
must be something \
around here to escape \
their grasp..."))

smlua_text_utils_dialog_replace(DIALOG_053,1,5,30,200, ("In the depths of the\
abyss we are. This chasm \
has seen endless days, \
or years of downpour.\
\
If you see little white \
markers, those are the\
main trigger to control \
the water. Be it flood \
or drain.\
Once you clear every\
thing out, we'll give\
you something special\
for last."))

smlua_text_utils_dialog_replace(DIALOG_054,1,5,30,200, ("If you are at the bottom\
of the chasm, this means\
the special challenge\
has begun.\
\
Climb up this scaffold \
and reach the surface.\
Easy, right? But there's\
a twist! You can't rise\
the water.\
Considering your level \
of jumping skill is, I\
think you're probably \
good to go now."))

smlua_text_utils_dialog_replace(DIALOG_055,1,4,30,200, (""))

smlua_text_utils_dialog_replace(DIALOG_056,1,6,30,200, (""))

smlua_text_utils_dialog_replace(DIALOG_057,1,4,30,200, ("Help! My poor little baby \
is missing! We were out\
for a swim trip and\
suddenly she's gone!\
I'm so ashamed as a\
mother for not looking \
after my own child!\
\
I beg of you, Sir, can you\
please find her? I'll \
do anything as long as \
she's not in danger!"))

smlua_text_utils_dialog_replace(DIALOG_058,1,5,30,200, ("Good lord! You found \
my baby! You gave me \
a heart attack! I told \
you to hold my hand \
when we go outside!\
I owe it to you, Sir Red \
Mustache! How can I ever \
repay you as thanks?\
\
\
Does this star I have \
piqued your interest?\
I can hand it over to \
you if you wish."))

smlua_text_utils_dialog_replace(DIALOG_059,1,5,30,200, ("That... can't be her!\
Where did you get that \
one from? I know that \
she's got a little pointy \
beak as mine!"))

smlua_text_utils_dialog_replace(DIALOG_060,1,6,30,200, ("If you know nothing \
about Super Mario 74, \
I recommend playing \
the original two first \
and then come back to\
this game later.\
And make sure to check \
out Lug's Delightful\
Dioramas as well as\
Lug's Tiny Torture. Even \
though they have some \
relation to the series."))

smlua_text_utils_dialog_replace(DIALOG_061,1,4,30,200, ("This game is bundled\
with a display layout.\
Use it to track down\
the stars. \
Or just don't, if you're \
into blind gameplay \
experience."))

smlua_text_utils_dialog_replace(DIALOG_062,1,3,30,200, ("You've hit the midway\
point. Keep it up, you're \
almost there! \
This section is different \
because of the bad idea \
I have with the toxic gas.\
Now it's perfect with\
what's intended to be. \
...yeah."))

smlua_text_utils_dialog_replace(DIALOG_063,1,6,30,200, ("Sudden change of mind!\
Those steep slopes are, \
once more, rideable with \
the shell. The blue ice \
may look like it but it's \
frozen lava.\
Oh, and about the jank \
collision, it's now gone. \
Reaching the top is \
easier than what I \
originally had in mind \
in the first version."))

smlua_text_utils_dialog_replace(DIALOG_064,1,5,30,200, ("Strong wind ahead!\
Don't get blown away!\
It has been reported \
that walking makes \
the path easier.\
Sometimes you'd be \
lucky grinding along \
ledges while the wind \
pushes you off if you \
run fast enough...\
Or... you could simply\
crawl as slow... like a \
baby turtle... yeah.\
The choice is yours."))

smlua_text_utils_dialog_replace(DIALOG_065,1,5,30,200, ("Good job making it this\
far. You see, this factory \
has been trapped in the\
rut for ages. \
\
Someone took out the \
flood and had to renovate \
the foundations from \
scratch. \
\
After all, wouldn't this \
be an opportune time \
to explore during its \
reopening?\
\
More information to\
follow from another\
sign at the upper end\
of the factory."))

smlua_text_utils_dialog_replace(DIALOG_066,1,5,30,200, ("You'd think using the\
Vanish Cap, there'd be\
a VERY easy way to\
get through flooring\
meshes? \
Sure it does for other\
worlds, but in this\
colorless world...\
Tsk, tsk.\
Fat chance.\
See this platform up to\
your left? To reach it, \
start your jumps from \
the tall pillar at the \
back corner."))

smlua_text_utils_dialog_replace(DIALOG_067,1,5,30,200, ("What just happened?\
A moment ago, you were \
in a park where the grass\
was more greener than \
ever and then..\
Boom, everything got \
burnt in a flash... Who \
is actually behind this \
phenomenon?"))

smlua_text_utils_dialog_replace(DIALOG_068,1,4,30,200, ("Almost at the top! \
Across the climb, the \
rocky patterns you see \
nearby are suspicious. \
And what's this island \
over there? It has been \
growing out of nowhere \
in the distance.\
Maybe you should look\
for an aerial device \
that's been lying around \
here..."))

smlua_text_utils_dialog_replace(DIALOG_069,1,6,30,200, ("Would you lookit that!\
To those who've suffered\
countless times dealing\
with the dreadful pit\
of firsties, here's your\
redemption!\
Of course, you still have\
to execute this technique,\
but you can retry as\
much as you want to\
eventually collect your \
reward."))

smlua_text_utils_dialog_replace(DIALOG_070,1,4,30,200, ("What a nasty swamp... \
It was a fine place to \
enjoy the view of those \
towers, but since the \
horrors with the burial \
ground, some jerk had \
the audacity to drop \
toxic waste to decompose\
the dead. Even so, the\
result remained the\
same and got even worse \
with the smell.\
I'd advise to stay safe, \
there's a 100 possiblity \
that you can get infected \
by the toxicity."))

smlua_text_utils_dialog_replace(DIALOG_071,1,6,30,200, ("Due to the intense \
pollution, the old \
bridges that connect \
the 3 tall towers have \
come loose.\
\
Did you know you can \
grab onto thin ledges?\
It may work if you \
walljump up this pole \
and pull back towards \
the ledge. Try it out!"))

smlua_text_utils_dialog_replace(DIALOG_072,1,3,30,200, ("This box is so sturdy \
it is difficult to punch\
your way in.\
Perhaps should you find\
a clue from another \
world to get through?"))

smlua_text_utils_dialog_replace(DIALOG_073,1,4,95,200, ("Oh no! The world \
collapsed and got turned \
upside down!\
\
But since you got this\
far enough, I have to\
remind you to use the\
firsties to reach the top.\
What, you forgot how to \
do them again? Or are \
you getting back at pony \
and gardening games?"))

smlua_text_utils_dialog_replace(DIALOG_074,1,5,30,200, ("Well well well! \
You have set foot in \
one of the trials of the \
Master Temple.\
\
Look at you! You were \
pretty shaken to witness \
the old lava peaks in a \
vacation vibe but get it \
together! \
It's not the time to rest \
yet! The hardest tasks \
can wait so let's start \
slowly with a new brand \
of variety here, shall we?"))

smlua_text_utils_dialog_replace(DIALOG_075,1,5,30,200, ("It's summer time!\
Let's enjoy the beach...\
What the... where's\
the water?\
\
Now there's this ugly\
puddle of quicksand\
taking over! How can \
you have fun when it's \
all hot and dried out?"))

smlua_text_utils_dialog_replace(DIALOG_076,1,5,30,200, ("HEY YOU! OVER THERE!\
COULD YOU QUIT \
GLARING AND WAVE \
YOUR HANDS AT ME?\
I BARELY KNOW YOU!\
OH. Sorry, didn't know\
you were there! I'm busy\
trying to shoo this guy. \
He's so creepy! Actually,\
will you do me a favor?\
No? Well, tell you what.\
I can hand you over this \
star if you help distract \
this guy out. \
Sounds fair, right?"))

smlua_text_utils_dialog_replace(DIALOG_077,1,6,150,200, ("Hey, what's the matter\
with this Toad over\
there? I don't know why \
he's yelling at me like \
I'm a weirdo.\
Anyways, I heard you\
can exit a world from \
the pause menu and \
leave it currently where \
you left off.\
It's more useful than\
having to backtrack\
from the beginning for \
early things you didn't\
get in the way."))

smlua_text_utils_dialog_replace(DIALOG_078,1,5,30,200, ("The sewer system has\
been improved a bit\
but I still recommend\
using the Lakitu Cam \
on neutral mode. \
You can get away if you \
zoom out less before\
it remains stuck by\
obstructed stuff from\
the outside and above."))

smlua_text_utils_dialog_replace(DIALOG_079,1,4,30,200, (""))

smlua_text_utils_dialog_replace(DIALOG_080,1,5,95,200, ("monkeyS"))

smlua_text_utils_dialog_replace(DIALOG_081,1,6,30,200, ("Compared to the rest\
of the stars in Bowser \
levels, the star within\
this marker will not \
take you back to the \
overworld. \
This means you can \
keep up a while looking \
for another star or head \
straight to the pipe up \
above."))

smlua_text_utils_dialog_replace(DIALOG_082,1,5,30,200, ("Hey Mario, you're off\
to recover some stars?\
I bet you are, it's what \
you are good at.\
\
This temple looks so \
intimidating. Did you \
know this was a belonged\
property of the Lords?\
\
I've heard the worlds\
within this temple are\
difficult it requires \
enough skill to complete. \
\
I feel so uneasy about \
this! Looks like something \
is affecting them on the\
inside!\
\
But you've gotten strong \
with the Stars, you can\
count on their power to \
find out what makes \
them this way!\
Speaking of which... \
Here, take it. I've hold \
on to this star for a \
while, hope it may help  \
you fill with courage."))

smlua_text_utils_dialog_replace(DIALOG_083,1,5,30,200, ("Mario? What are you\
doing here? I thought\
you were gone off to\
Spaghetti Land.\
\
Huh, there no such thing \
that exists? That's fair, \
I knew this commercial \
was a scam but you idiot \
went off to believe that!\
I have better things to \
do on my day off, so\
why don't you go bother\
someone else with your\
antics?\
Rather, I was waiting for\
you to show up. I found\
this star floating in the \
lake this morning.\
\
And why is it orange?\
We had these for \
Halloween decorations \
so it can't be happening \
that soon, right?"))

smlua_text_utils_dialog_replace(DIALOG_084,1,4,30,200, ("Owww! Let me go, you \
big bully! Who do you\
think you are to grab me, \
an inoffensive bunny?\
Yes, I can talk, unlike my\
other bunny friends.\
You've litterally ruined\
my lunch time! \
And I remember you\
being the same guy \
taking them to those \
hungry Toadies to feed!\
I mean no trouble, so \
please don't let them\
eat me! I have a bitter\
taste!  \
What do you want? A\
star? Okay, here, I'll \
give you one if you put \
me down."))

smlua_text_utils_dialog_replace(DIALOG_085,1,5,30,200, ("Say, have you caught \
up to one of the air \
ducts around here, \
haven't you?\
\
Apparently, they are \
connected to the top, \
and on the matter of\
subject, certain rooms\
are colored.\
Does this mean anything\
to you? My guess is that\
you have to find out \
beyond the ceiling.\
\
I also can sense a  \
passageway from here \
but you might just run\
into a secret wall to \
discover."))

smlua_text_utils_dialog_replace(DIALOG_086,1,4,30,200, ("To enter the vibrant\
Sea Salt Peaks, all you\
need to open the door\
is 90 stars."))

smlua_text_utils_dialog_replace(DIALOG_087,1,5,30,200, ("Only the brave are\
allowed to reach the\
Veninium-Sphere unless\
they possess 100 stars \
to enter."))

smlua_text_utils_dialog_replace(DIALOG_088,1,5,30,200, ("The Delombru-Sphere \
will not tolerate the \
bold and strong gamer \
amongst others to defy \
its wrath. \
That is, if you dare \
bring along with you \
the maximum load of \
110 stars."))

smlua_text_utils_dialog_replace(DIALOG_089,1,5,30,200, ("Some say 120 stars is \
the required amount to \
break the seal in order\
to enter the unreachable\
Rainbow Realm."))

smlua_text_utils_dialog_replace(DIALOG_090,1,5,30,200, ("What just happened?\
A moment ago, you were\
in a park where the \
grass was greener than\
ever and then...\
Boom, everything got \
burnt in a flash... Who \
is actually behind this phenomenon?"))

smlua_text_utils_dialog_replace(DIALOG_091,2,3,30,200, ("What lies behind this\
door is a secret like\
no others has ever seen.\
To uncover that mystery,\
a total of 150 stars is\
required."))

smlua_text_utils_dialog_replace(DIALOG_092,1,5,30,200, ("While you were having\
fun basking in the beach,\
the second you entered\
the pipe, this place has\
suddenly gotten dried out.\
Seriously, what's going \
on around here? \
The mysteries of the \
world still need to be\
unfold!"))

smlua_text_utils_dialog_replace(DIALOG_093,1,5,30,200, ("So this is what it all \
comes down to, huh. \
You dare cause a ruckus\
in my own base, you\
damned plumber?!\
Yes, I was the one who's\
responsible of this mess!\
I wasn't aware how this\
power could change many\
worlds as I want...\
Still, you just won't give \
up even when I plan to \
come back and eventually\
get rid of you, huh?!\
\
I'll make sure my fists \
will send you in a black \
hole so nobody will save \
you anymore!\
Bring it home, Mario!"))

smlua_text_utils_dialog_replace(DIALOG_094,1,5,30,200, ("You made it! For you\
to survive this ride must\
have been real insane!\
\
\
For getting this far,\
you have arrived to the \
world's peaceful haven, \
the Triarc-Bridge.\
\
You won't die at this\
point, though we figured \
it would be enough to \
stack lives if you do. \
...Or not.\
Your final star is along \
the way, but first, we'll \
let you take a moment \
to revisit before leaving."))

smlua_text_utils_dialog_replace(DIALOG_095,1,6,30,200, ("Yo! What's crashing?\
This is LinCrash here!\
How did it go, as you've\
gotten all the stars?\
\
\
You're about to beat the\
game, and by that, \
I just want to give you \
my thanks for playing \
if you're still going at it \
non-stop!\
This hack was pretty\
much something I did to\
myself and for fans \
because now SM74 has\
hit the decade. Yes, \
10 years of its release! \
I want to express my\
sincere gratitude to\
Lugmillord, for making\
what has become of\
SM64 nowadays.\
\
If it wasn't for him,\
ROM hacks could've\
gone wrong, but hey, \
we got so many talents\
living up to their name.\
\
I also owe my thanks\
to the SM64 ROM Hack\
Community, to keep me \
pushing forward, with\
motivation on and off, \
to produce this project!\
It's been a fun ride, but\
I will not stop there for\
as long as I create more\
funtimes with my new\
upcoming remakes!\
\
Of course, don't forget\
to subscribe to me and\
Lugmillord to stay in\
touch for more!\
We hope you enjoyed \
the nostalgia trip.\
Once again: \
Congratulations, you're\
truly a super player!\
\
This is LinCrash, signing\
out."))

smlua_text_utils_dialog_replace(DIALOG_096,1,5,30,200, ("I know you were expecting\
some kind of extra after \
this, but I didn't have\
time to make a list of\
Achievements.\
But you can make your \
own to increase crazy\
content in this hack.\
New challenges give\
new freedom, y'know!\
Hit me up if something\
comes to mind, I real \
appreciate helping \
hands from gamers. :)"))

smlua_text_utils_dialog_replace(DIALOG_097,1,3,30,200, ("Here lies a gamer in \
this shack. His last \
words were: \
『WHY WOULD YOU \
TAKE DAMAGE???』"))

smlua_text_utils_dialog_replace(DIALOG_098,1,3,95,200, ("Here lies a gamer in \
this pillar. His last \
words were: \
『GRAB THE THING AT\
LEAST!』"))

smlua_text_utils_dialog_replace(DIALOG_099,1,5,95,200, ("It's a disaster! Venus \
Fire Traps have gone on \
a rampage lately and \
they've burned down that \
beautiful green park!\
Tear 'em out at once!\
They can't be that far \
away, you should be able\
notice some leftover pots\
around here.\
Once you got the job \
done, a reward will\
appear on top of that \
fortress!"))

smlua_text_utils_dialog_replace(DIALOG_100,1,3,95,200, ("This fence is, unlike the\
rest, is not trespassable \
with the Vanish Cap. \
Instead, you need a more \
bizarre means to get \
through it, but where?"))

smlua_text_utils_dialog_replace(DIALOG_101,1,3,95,200, (""))

smlua_text_utils_dialog_replace(DIALOG_102,1,3,30,200, ("Here lies a gamer inside \
this sealed room. His \
last words were: \
『I SAVESTATED.\
FUUUUUUUUUU-』"))

smlua_text_utils_dialog_replace(DIALOG_103,1,4,95,200, ("Here lies a gamer within\
the mushrooms. His \
last words were: \
\
『IT'S NOT MY RUN \
ANYMORE, IT'S THE \
EYEBALL'S F☆☆☆ING\
RUN!』"))

smlua_text_utils_dialog_replace(DIALOG_104,1,3,30,200, ("You can get in many\
surfaces not only as \
walls, but as floors too.\
Find the Vanish Cap to\
check out where the pipe\
can possibly lead to."))

smlua_text_utils_dialog_replace(DIALOG_105,1,3,95,200, (""))

smlua_text_utils_dialog_replace(DIALOG_106,1,2,95,200, ("That'll be 5 coins. Thanks \
for your patronage."))

smlua_text_utils_dialog_replace(DIALOG_107,1,4,95,200, ("Hey! Stop killing the\
already dead! \
\
\
We may still be dead, \
but that doesn't mean \
you have to take us to \
Death again!"))

smlua_text_utils_dialog_replace(DIALOG_108,1,3,95,200, ("How dare you kill our\
Boo-therhood?! \
\
We won't show mercy to\
mustachioed monsters! \
Go get him, guys!"))

smlua_text_utils_dialog_replace(DIALOG_109,1,5,95,200, ("This warp pad serves as \
a shortcut upon the great \
halls, so you won't have\
to redo the walljumping \
section over.\
It will only activate on\
Stars 3-6, so I suggest\
you start grabbing the \
first two stars from the \
lower half here."))

smlua_text_utils_dialog_replace(DIALOG_110,1,4,95,200, ("In this hole uncovers \
the warp pad leading to \
the lite, yet sweet \
Morbid Deadly Puzzle.\
Since it ramps a little\
less harder than its \
ancestor, this only\
activate on Stars 5-6."))

smlua_text_utils_dialog_replace(DIALOG_111,1,4,95,200, ("Danger ahead!\
The tower near you \
is infested by sentient,\
electric-feeding Amps!\
Avoid them at all costs \
until you grab the star\
while still hanging down \
the vines!\
Are you ready? Press\
the switch to begin. \
Boxes will pop up at the\
tower's opening."))

smlua_text_utils_dialog_replace(DIALOG_112,1,4,30,200, ("Here lies a gamer inside \
this spike. His last words \
were: \
\
『DUST! I'M SO MAD!\
I'M SO MAD I DON'T\
WANNA RUN THIS GAME\
BECAUSE OF... DUST!』"))

smlua_text_utils_dialog_replace(DIALOG_113,1,3,30,200, ("Here lies a gamer in \
this pack of corkboxes.\
His last words were:\
『I HIT THE WALL!!!』"))

smlua_text_utils_dialog_replace(DIALOG_114,1,5,95,200, ("You again? Don't you\
ever give up? It's time\
for some recognition\
because I've had it out\
with you!\
I'll see you try since \
this patch of sand is \
sticking you down. \
Have at you!"))

smlua_text_utils_dialog_replace(DIALOG_115,1,5,95,200, ("I can't believe it!\
Even with this suitable\
trap, you still remain\
unstoppable!\
\
Lady luck, how could\
you do this to me?!"))

smlua_text_utils_dialog_replace(DIALOG_116,1,5,95,200, ("NO WAY!\
Every time! How did I \
lose to you?! My plan\
was so perfect!\
\
I stomped the ground to \
create a big hole and that \
didn't stop you once!\
And these fire bullets\
are STILL useless!\
I'll be back! And when \
I do, you'll regret \
facing me, the true\
ruler of the garden!"))

smlua_text_utils_dialog_replace(DIALOG_117,1,5,95,200, ("Hey! Who are you to\
wipe your dirty feet \
on my glorious face?\
Wha- I DO have a face.\
TWO, no less!\
Got a problem with that,\
midget? You'll laugh \
last when you'll get \
your butt handed to \
you now!"))

smlua_text_utils_dialog_replace(DIALOG_118,1,5,95,200, ("Augh!! That hurts!!\
What is wrong with you, \
man?! You don't have \
to bite me in the hand, \
god darn it!\
Now I've done it again! \
All because of my stupid \
hand jokes...! This is the\
worst! I'm outta here!"))

smlua_text_utils_dialog_replace(DIALOG_119,1,6,30,200, (""))

smlua_text_utils_dialog_replace(DIALOG_120,1,4,30,200, (""))

smlua_text_utils_dialog_replace(DIALOG_121,1,5,30,200, ("Impossible! How did you\
managed to defeat me?!\
I could've sworn the\
game asked you to bring \
all 120 stars to get here!\
Did you cheat your way\
like that? No matter, I \
won't lose to the likes \
of you, or any gamer \
that controls you, ever!"))

smlua_text_utils_dialog_replace(DIALOG_122,1,4,30,200, ("Well, ain't that something. \
This new place has both \
temples fuse together to \
become one of its kind!\
Its restoring process is \
rather unusual than \
the previous worlds \
we've visited.\
Seems it couldn't split \
up with its evil dimension \
and pieces started to \
deteriorate a bit.\
Anyways, take a look at \
the spiritual temple\
of hope, that is the\
Veninium-Sphere.\
This level got itself a lite \
update over the last one. \
Got to say, I'm happy \
with the results. \
That's right, you get no\
quicksand or super cheap \
obstacles pestering you\
around.\
And the good side: the \
amount of red coins\
have been reverted to 8.\
Relieved now?"))

smlua_text_utils_dialog_replace(DIALOG_123,1,4,30,200, ("The 『Kubus of Hope』.\
By its meaning, it gives\
you another chance and \
pray for good luck.\
It is connected to the \
Light side but it's energy \
core was already struck \
by the poison.\
It seems as though its \
current state alters the \
temple from every place \
you go."))

smlua_text_utils_dialog_replace(DIALOG_124,1,4,30,200, ("Oh no... There is no \
removal from madness \
and denial built within \
the dreaded Sphere.\
Prepare to face off\
the Delombru-Sphere,\
the spiritual temple of \
despair.\
That place is completely\
shattered beyond time,\
but you got to endure it \
for the sake of treasure.\
The good news: it got \
remade to be less harder, \
but you better watch\
out for deadly hazards. \
The red coin factor is\
also back to 8. And they \
all are at ground level. \
Talk about lucky.\
Hope you enjoy the lite\
changes, and thanks to \
Lug for the wise advices\
and help!\
Now, get ready for the\
final, brave gamer!"))

smlua_text_utils_dialog_replace(DIALOG_125,1,4,30,200, ("The 『Kubus of Despair』. \
Don't stare at it. \
You were going to give \
yourself up.\
And if you do, you won't\
value your worth and\
then end up being \
depressed.\
The temple has fallen to \
the darkness as it now\
embraces evil and death.\
How tragic..."))

smlua_text_utils_dialog_replace(DIALOG_126,2,6,30,200, ("Well done, you have \
reached the top. Yet \
there's one last thing\
to do to finish the ritual.\
Over the decade, word\
has been said that the \
gold moved within the \
walls of peril.\
They are nearby the\
same places as before,\
although different now.\
But where exactly?"))

smlua_text_utils_dialog_replace(DIALOG_127,3,4,30,200, ("Remember: the camera \
is a nuisance in most \
specific areas it can\
get stuck on from above.\
If it doesn't cooperate\
facing things inwards,\
be sure to stay on Lakitu \
Cam with a neutral POV."))

smlua_text_utils_dialog_replace(DIALOG_128,1,4,95,200, ("HA! That was useless!"))

smlua_text_utils_dialog_replace(DIALOG_129,1,3,30,200, ("Here lies a gamer in this \
corner of the valley. \
His last words were: \
『NO F☆☆☆ING WAY!!!\
I MOVED AROUND THE\
GOOMBA!!!』"))

smlua_text_utils_dialog_replace(DIALOG_130,1,3,30,200, ("Here lies a gamer near \
the lava pit. His last \
words were: \
『I CANNOT SEE!!! \
I WANNA SEE!!! HELLO!!! \
ARGH, F☆☆☆ YOU!!』"))

smlua_text_utils_dialog_replace(DIALOG_131,1,3,30,200, ("Here lies a gamer on \
top of the temple. His \
last words were: \
『NO WAYYYYYYY!!!!』"))

smlua_text_utils_dialog_replace(DIALOG_132,1,4,30,200, (""))

smlua_text_utils_dialog_replace(DIALOG_133,1,5,30,200, ("Oh hey. I suppose you're \
not dreaming anymore.\
Took you a while to get \
to business dealing with\
Bowser's tyranny!\
I'm glad the world's at\
peace, yet we had our \
own problems to take \
care of right here!\
\
Bowser's done for and \
I can see this place has\
turned really... nice. \
Are you going off to \
another adventure?\
That's great. Look up \
to the other Toads for \
hints once they'll stop \
complaining for the \
other day."))

smlua_text_utils_dialog_replace(DIALOG_134,1,5,30,200, ("It's the future, people!\
We buy, sell, and consume\
more! What more could\
you ask for?\
\
If you strike down a\
massive bag of gold, \
you sure good to go for\
happiness! But isn't\
that a shame?\
It's like in party games,\
you own a star from \
stealing coins out in the\
open, though you don't\
really mean it.\
Our lives are at risk, \
though we've messed up \
for... y'know, eating the \
living...? Ah, it's not \
very important.\
Anyway, if you see gold:\
just take it lightly but \
don't waste it for every\
selfish choice that you \
make! Is that clear?"))

smlua_text_utils_dialog_replace(DIALOG_135,1,5,30,200, ("Looking back when I \
fancied the pale grassy \
fields, I was screaming \
on the inside thinking \
of ending it all.\
But ever since I see this \
new valley, it makes me \
a little less sad. \
In fact, I think it's a \
fresh start. \
It's going to be alright \
after the disaster and \
all that, thanks to your \
hero duties.\
\
Aside for a couple of \
things I've lost in the\
past, I don't have to feel \
worried now..."))

smlua_text_utils_dialog_replace(DIALOG_136,1,5,30,200, ("Bowser really caused \
our lives worse back\
then but from now on\
we'll toughen up by \
in our defense!\
About that, any shroom \
you find will replenish \
your health so if you get \
damaged, take these to \
stay alive!\
You don't even need\
lives, either. You are\
strong enough if you're\
in a pinch, so expect\
endless attempts."))

smlua_text_utils_dialog_replace(DIALOG_137,1,5,30,200, ("Hey Mario, I feel bad\
when I said you were\
useless. But still, we've \
relied on you to pay \
for all the damage.\
By the way, is this \
camera of yours doing \
fine? ...Huh, thought so. \
Why don't you save up \
for another one?\
Considering the newly \
improved technology, \
I've heard one can \
move different angles\
with the D-pad.\
You can afford it in\
stores, although you're\
short on coins from\
spending them all on\
your pasta dreams..."))

smlua_text_utils_dialog_replace(DIALOG_138,1,3,30,200, ("Take a deep breath\
and enjoy the relaxing \
view of the lake. \
This will purposely wash \
away all the problems \
in your life."))

smlua_text_utils_dialog_replace(DIALOG_139,1,4,30,200, ("The floating star and \
the other star on the \
building are pretty\
tricky to reach... \
At this point, this is \
where the D-pad camera \
control (Lakitu mode) \
comes in handy.\
Since this is training,\
I suggest some trial and\
error and see which\
angle works the best.\
By the way, there used \
to be an invisible wall \
here back in the days.\
Y'know, SM64 logic..."))

smlua_text_utils_dialog_replace(DIALOG_140,1,5,30,200, ("This place sure looks \
identical than before \
but it's worth noting \
there are slight, little \
changes around.\
Take the green hills,\
or, the house over there. \
You might want to \
check them in closely\
if you're curious..."))

smlua_text_utils_dialog_replace(DIALOG_141,1,5,150,200, ("You got a star! The first\
in the collection!\
What? Thought you \
were done now? Well \
you shouldn't be."))

smlua_text_utils_dialog_replace(DIALOG_142,1,5,150,200, ("What makes you think\
celebrating as getting\
3 stars was a big enough\
achievement? Jokes\
on you man."))

smlua_text_utils_dialog_replace(DIALOG_143,1,5,150,200, ("Aren't you overreacting\
to these milestones?\
I mean, you're just at the \
beginning. Gee."))

smlua_text_utils_dialog_replace(DIALOG_144,1,5,150,200, ("I take it that you have \
gathered 30 stars, \
have you? Or are you \
just being lazy? \
\
There's more to be \
explored, yet you're \
not working seriously \
this time! \
C'mon now, get moving!"))

smlua_text_utils_dialog_replace(DIALOG_145,1,6,150,200, ("Well, there I see you\
got 50 stars. You sure\
do have quite a little \
experience, but I hope \
you will be surprised \
with what comes next. \
But who am I kidding? \
I'm supposed to laugh \
at you fail! That's right, \
so get going, I'll still be \
watching you for the\
hard times!"))

smlua_text_utils_dialog_replace(DIALOG_146,1,5,150,200, ("Since this is the last\
interruption, I admit\
that you're improving\
for getting this far,\
however...\
You've got a ways ahead \
to finish the second half.\
Are you now prepared?\
Soon you'll be conflicted\
to tough roadblocks.\
The adventure's nowhere \
near close, otherwise \
as a gamer, redeem \
yourself and become \
victorious 'til the end!"))

smlua_text_utils_dialog_replace(DIALOG_147,1,5,30,200, ("Bowser's hidden up there! \
You only have one last \
shot to make it!\
\
\
I know you'd like some\
box parkour, yet I'm old \
to come up with ideas \
that's too frustrating for \
Mario's fragile abilities.\
Instead I'd recommend\
aiming the cannon at the \
highest pitch for the pipe.\
Yeah. Don't be shy, just\
go for it.\
(Trust me, this is not\
another prank, but once\
you do, you'll find out\
that is very funny :P)"))

smlua_text_utils_dialog_replace(DIALOG_148,1,4,30,200, ("Gather all 5 spreaded\
star shards, and the \
star shall shine on top \
of the large rock."))

smlua_text_utils_dialog_replace(DIALOG_149,1,4,30,200, ("A mysterious object used \
to be in this spot.\
But its location moved \
in within the fortress. \
But how would you get\
to it, you ask? Seek a\
hidden exit you may \
find in the outer wall."))

smlua_text_utils_dialog_replace(DIALOG_150,1,5,30,200, (""))

smlua_text_utils_dialog_replace(DIALOG_151,1,4,30,200, (""))

smlua_text_utils_dialog_replace(DIALOG_152,1,3,30,200, (""))

smlua_text_utils_dialog_replace(DIALOG_153,1,5,30,200, ("They say jumping on a\
heave-ho gains little\
extra height when they \
fling you off to almost \
reachable spots."))

smlua_text_utils_dialog_replace(DIALOG_154,1,5,30,200, ("Need something from\
me, Mario? I'm sorry, \
but I already gave you the \
star I had, remember?\
\
But if you feel the need\
to keep me company, \
I don't mind at all. \
This scene's heating up\
from here, you feel me?"))

smlua_text_utils_dialog_replace(DIALOG_155,1,4,30,200, ("I-is this guy over there\
gonna keep glaring at\
me? He's getting on my\
nerves...."))

smlua_text_utils_dialog_replace(DIALOG_156,1,5,30,200, ("Y'know, guarding the \
castle in my day off\
is such a drag. Heck,\
don't get me started \
about Peach's sassyness.\
Like, seriously, she's the \
one at fault getting \
herself kidnapped all \
day!\
\
I wish she gets run over \
by a train or something!\
I mean... sigh. That's how\
I feel lately. I'm awkward \
with my thoughts..."))

smlua_text_utils_dialog_replace(DIALOG_157,1,6,30,200, ("Here we are.\
This is the Rainbow \
Realm, Bowser's space \
base, located deep \
down the far reaches \
of the galaxy.\
Which really doesn't \
make sense why we\
suddenly got in outer\
space, but blame it on\
the lore, I guess...\
\
How he was able to\
build it here is beyond \
me, for sure we have to \
find out if he's behind \
this world change \
phenomenon.\
Also notice some \
similarities to a certain\
Sanctuary. Hm, do we\
sense a twist?\
Let's move on."))

smlua_text_utils_dialog_replace(DIALOG_158,1,5,30,200, ("Hah! I knew something's\
off about this... way to\
go, Bowser! It was too \
good of a reveal!\
\
The idea is simple as\
always: elude the paths\
and open the cannon\
to reach the main core.\
\
Considering this is Ztar \
Zanctuary gone normal,\
Bowser's traps shouldn't \
be this ruthless to deal \
with... right?"))

smlua_text_utils_dialog_replace(DIALOG_159,1,6,30,200, ("A red drunk Yoshi once\
figured the mystery \
of this room and how to\
bypass it. Thus, the red \
walls are a monument \
of his success. \
Walljump carefully using\
angles with the D-Pad \
to prevent death. \
Every precise angle \
matters from here on.\
\
...Or you could skip those\
if you're an horrible\
person with no patience.\
Whatever. We don't \
care less about choices."))

smlua_text_utils_dialog_replace(DIALOG_160,1,5,30,200, ("You have reached the \
main core, but, it's \
strange... there should \
be a pipe in this spot \
right here.\
Did Bowser thought of\
everything to not let\
us sabotage his hideout?\
There's still some more \
out to investigate!"))

smlua_text_utils_dialog_replace(DIALOG_161,1,4,30,200, ("O AAAAAHOOOOOLE!!!\
I can't just believe the\
Toads ate my people \
alive!\
I may have survived for \
two decades but it is \
now the time to give 'em \
some payback!\
And YOU! You don't\
deserve to live for letting \
them for what they've \
done, so overdose on this!\
Everybody will suffer\
from what I've suffered \
too! Mark my words!"))

smlua_text_utils_dialog_replace(DIALOG_162,1,5,30,200, ("Not you again! Let go!\
When will you understand \
that I don't taste good?\
What do you want from\
me, this time? \
Another star? Fine, just \
take it and leave me be! \
That's the last time I've\
had it out to meet a \
meanie such as you!"))

smlua_text_utils_dialog_replace(DIALOG_163,1,5,30,200, ("NO!!! Beaten again!\
And you've taken all\
of my 155 Power Stars \
away from me!\
This is hopeless! \
Even when I'm finally \
able to control Peach's \
magic or the Stars, \
none of my vicious plan \
works against you! \
How can such a plumber \
be so strong?!\
Don't think you've won\
this time yet, Mario! \
\
The day I'll take your \
super gaming senses \
away, no peace will ever\
be returned! But for now, \
let's start the ending."))

smlua_text_utils_dialog_replace(DIALOG_164,1,4,30,200, (""))

smlua_text_utils_dialog_replace(DIALOG_165,1,5,30,200, ("I'm still amazed you're\
able to return here\
for many years.\
So... welcome back."))

smlua_text_utils_dialog_replace(DIALOG_166,1,4,30,200, ("What's going, you ask?\
Well, I can't tell since\
I've spent an eternity\
here stuck as a sign.\
If only I could grow two\
feet, you wouldn't annoy\
me already!"))

smlua_text_utils_dialog_replace(DIALOG_167,1,3,30,200, ("This guy's been waiting\
here alone. I've been\
waiting here alone.\
Isn't that what we do\
to expect something\
to happen til then?\
'Course you won't know.\
You're too insensitive\
about time."))

smlua_text_utils_dialog_replace(DIALOG_168,1,5,30,200, (""))

smlua_text_utils_dialog_replace(DIALOG_169,1,5,30,200, ("Did you know that Bill \
Board and the Sign Lord \
are apparently both the \
same sign we used to \
know? Surprising. \
But what if one of us\
signs happen to be these \
guys? Guess we'll never \
know. At least, for now."))

