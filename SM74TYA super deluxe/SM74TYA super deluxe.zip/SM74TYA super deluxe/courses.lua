smlua_text_utils_course_acts_replace(COURSE_BOB, (" 1 DICE DOMAIN"),	("HERE WE GO AGAIN!"),	("BABY BUTTHURT"),	("HELL RIDER"),	("SECRET OF THE FORTRESS"),	("SCALE THE TOWER -MC-"),	("RED COIN BLAZING BATH"))

smlua_text_utils_course_acts_replace(COURSE_WF, (" 2 CONCRETE JUNGLE"),	("OFF THE WALL"),	("THE CAGED VINE TOWER"),	("HUMAN CATAPULT"),	("WILDSTYLE GROUND ZERO"),	("THE JUNGLE UNDERSIDE"),	("THE VINE'S HIDDEN TREASURE"))

smlua_text_utils_course_acts_replace(COURSE_JRB, (" 3 WALLOWING WELLS"),	("RISING TIDE"),	("UPON THE CRATER"),	("THWOMPS ON ACID"),	("SUNKEN TREASURE"),	("WALL OF FAILURE RUN -VC-"),	("WATERLESS MODE"))

smlua_text_utils_course_acts_replace(COURSE_CCM, (" 4 BOGEY BAYOU"),	("SMELLS LIKE MIST SPIRIT"),	("THROUGH THE SEWER SYSTEM"),	("HIDDEN FURNACE"),	("SLEEP WITH THE BUBBAS"),	("BREAK INTO THE MANSION"),	("ALTERNATE ENTRANCE"))

smlua_text_utils_course_acts_replace(COURSE_BBH, (" 5 FLAMEWORK FACTORY"),	("FACTORY REINSPECTION"),	("WATCH FOR HOLES"),	("TUNNEL TIME - RED SIDE"),	("TUNNEL TIME - GREEN SIDE"),	("TUNNEL TIME - BLUE SIDE"),	("TUNNEL TIME - YELLOW SIDE"))

smlua_text_utils_course_acts_replace(COURSE_HMC, (" 6 STALACTITE CAVE"),	("TUBE IN THE DEEPER DARK"),	("DRENCHED CORRIDOR"),	("PEARL HARBOR"),	("RECOMBO RE-CAP -MC★VC-"),	("CHUCK 'EM, CLIP 'EM"),	("CAVE OBSTACLE COURSE -WC-"))

smlua_text_utils_course_acts_replace(COURSE_LLL, (" 7 CRUMBLE RUMBLE TOWER"),	("ROCKY ROAD"),	("RED GOLD DIGGER"),	("ROUGH FIGHT WITH KING WHOMP"),	("TIMED TRAP BOXES"),	("LONELY ISLAND FLY-BY -WC-"),	("UNDER YOUR FEET"))

smlua_text_utils_course_acts_replace(COURSE_SSL, (" 8 ABSOLUTE ZEROASIS"),	("FOREVER UNDER CONSTRUCTION"),	("CLUMSY PYRAMID"),	("BLIZZARD BOUT -MC-"),	("ICING ON THE MOUNTAINSIDE"),	("DEEP SEA FROSTBITE"),	("STRAIGHT OUT NARROW"))

smlua_text_utils_course_acts_replace(COURSE_DDD, (" 9 NATURE NOCTURNE"),	("KING BOB-OMB'S NIGHT OUT"),	("TIMBER FUNDS FOR RESTORATION"),	("THE WINDMILL'S CHALLENGE"),	("UNDER THE GROUNDS"),	("ABRIDGED VIEW FROM BELOW"),	("THE CAVE BEHIND BARS"))

smlua_text_utils_course_acts_replace(COURSE_SL, ("10 QUICKSAND BEACH"),	("RUBY RUMBLE"),	("LOST SWITCH OF THE BAR"),	("TROUBLESOME FIREWOOD"),	("HOLED UP SECRETS"),	("SUN! SAND! SURF!"),	("IN THE QUICKSAND PIT"))

smlua_text_utils_course_acts_replace(COURSE_WDW, ("11 POLLUTED POND"),	("RED GARBAGE"),	("BACK TO THE HIDEOUT"),	("TOWER OF FRAGILITY"),	("ARCH-ENEMIES"),	("RISE OF THE SAND PLATEAU"),	("PAST REMNANT"))

smlua_text_utils_course_acts_replace(COURSE_TTM, ("12 CLIFF OF TIME"),	("EYESTERGEIST"),	("BIG BOO IN THE PARALLEL WORLD"),	("LATERAL STAR BLUES"),	("PROBLEMATIC PUZZLE"),	("ART OF FIRSTY"),	("PRIDE AND GREED"))

smlua_text_utils_course_acts_replace(COURSE_THI, ("13 SEA SALT PEAKS"),	("RACE WITH BARRAKOOPA"),	("RESCUE THE PENGUINS"),	("HOT ARCH CROSSING"),	("SEARCH FOR THE FIVE HOOPS"),	("METAL ANCHOR -MC-"),	("THE SEASIDE'S MYSTERIOUS OBJECT"))

smlua_text_utils_course_acts_replace(COURSE_TTC, ("14 VENINIUM-SPHERE"),	("TOWER OF THE SOUTH"),	("THE HALLS OF FATE"),	("KUBUS KONNECTION"),	("GOLDEN RARITY"),	("SKYWARD SHATTERS"),	("A SLIVER OF RED LIGHTS"))

smlua_text_utils_course_acts_replace(COURSE_RR, ("15 DELOMBRU-SPHERE"),	("UNWORLDLY CORE"),	("DUNGEON DOMINANCE"),	("TOWER OF THE NORTH"),	("HOLLOW ARTIFACT -VC-"),	("MORBID DEADLY PUZZLE, BUT SWEET"),	("NAUGHTY NIGHT, EVIL BLIGHT"))

smlua_text_utils_secret_star_replace(15 + 1, ("   BOWSER'S PARK PARTY"))
smlua_text_utils_secret_star_replace(16 + 1, ("   BOWSER'S TIDAL TROPICS"))
smlua_text_utils_secret_star_replace(17 + 1, ("   BOWSER'S RAINBOW REALM"))
smlua_text_utils_secret_star_replace(18 + 1, ("   UNDERGROUND SLIDE"))
smlua_text_utils_secret_star_replace(19 + 1, ("   AERIAL ALPINE"))
smlua_text_utils_secret_star_replace(20 + 1, ("   LAVA PIT OF INVERSION"))
smlua_text_utils_secret_star_replace(21 + 1, ("   DUSTY DARKNESS"))
smlua_text_utils_secret_star_replace(22 + 1, ("   TRAINING GROUNDS"))
smlua_text_utils_secret_star_replace(23 + 1, ("   VOID OF THE EAST"))
smlua_text_utils_secret_star_replace(24 + 1, ("   GRANDMASTER'S GOAL"))
smlua_text_utils_castle_secret_stars_replace(("   BONUS SECRET STARS"))
smlua_text_utils_extra_text_replace(0,("YOU GOT A BONUS STAR!"))
smlua_text_utils_extra_text_replace(1,(""))
smlua_text_utils_extra_text_replace(2,(""))
smlua_text_utils_extra_text_replace(3,(""))
smlua_text_utils_extra_text_replace(4,(""))
smlua_text_utils_extra_text_replace(5,(""))
smlua_text_utils_extra_text_replace(6,(""))
