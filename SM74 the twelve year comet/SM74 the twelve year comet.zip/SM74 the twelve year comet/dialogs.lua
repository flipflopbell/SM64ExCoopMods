smlua_text_utils_dialog_replace(DIALOG_000,1,5,30,200, ("Hello and welcome to \
SUPER MARIO 74: \
THE TWELVE YEAR \
COMET!\
\
This hack, or edit, is \
a re-ash of TEN YEARS \
AFTER but with green\
stars spread around\
the levels.\
There are 101 green\
stars to collect, and \
most signs are changed \
so please take the time\
to read up for hints.\
Green stars are very \
intricate to get to them, \
so it's worth using your \
head if you already \
know the game by heart.\
Oh and one last thing:\
do NOT go for hard\
green stars WITHOUT\
practicing them first!\
Good luck!"))

smlua_text_utils_dialog_replace(DIALOG_001,1,5,95,200, ("WC"))

smlua_text_utils_dialog_replace(DIALOG_002,1,5,95,200, ("Attention!\
The two stars floating\
high above the jungle\
are very tricky to catch\
but not quite.\
They require a bit of\
momentum precision\
if you understand how\
physics work in base \
vanilla Mario 64.\
The star near the tower\
needs a quick-end \
reaction with a ground\
pound if you reach it\
close enough.\
The star by the outer \
wall has to be done with\
rather a tiny angle off \
a least straight chain \
long jump."))

smlua_text_utils_dialog_replace(DIALOG_003,1,5,95,200, ("You might think this \
railing is too steep to \
walk on and it will\
PROBABLY clip you off\
the side?\
Well then, guess what. \
I'll turn over this fact \
that is not true. Make \
it up to the star and\
you'll be fine."))

smlua_text_utils_dialog_replace(DIALOG_004,1,3,95,200, (""))

smlua_text_utils_dialog_replace(DIALOG_005,1,3,30,200, (""))

smlua_text_utils_dialog_replace(DIALOG_006,1,3,30,200, ("Now now, dude."))

smlua_text_utils_dialog_replace(DIALOG_007,1,4,30,200, (""))

smlua_text_utils_dialog_replace(DIALOG_008,1,5,30,200, ("Our cannons are all\
open and free of use.\
You don't need our \
accord at all so help \
yourself anytime.\
And above all, we\
humbly thank you for \
using our services from \
yours truly,\
Bob-omblast Corp!"))

smlua_text_utils_dialog_replace(DIALOG_009,1,4,30,200, ("Hi. Remember me?\
You good?\
\
//Go//// Not Yet"))

smlua_text_utils_dialog_replace(DIALOG_010,1,4,30,200, ("WC\
Save?\
\
//Yes////No"))

smlua_text_utils_dialog_replace(DIALOG_011,1,5,30,200, ("MC\
Save?\
\
//Yes////No"))

smlua_text_utils_dialog_replace(DIALOG_012,1,4,30,200, ("VC\
Save?\
\
//Yes////No"))

smlua_text_utils_dialog_replace(DIALOG_013,1,5,30,200, ("100s\
Save?\
\
//Yes////No"))

smlua_text_utils_dialog_replace(DIALOG_014,1,4,30,200, ("God gamer!\
\
//YEA!////NAY!"))

smlua_text_utils_dialog_replace(DIALOG_015,1,5,30,200, ("There used to be a cap \
block in this spot.\
Unfortunately, you'll\
cross any of them not\
worth of use anywhere.\
You don't even need to \
press the cap switches \
as all cap blocks are \
already active."))

smlua_text_utils_dialog_replace(DIALOG_016,1,4,30,200, ("This door leads to the\
ending. You need the \
entire stock of 101\
Green Stars to unlock it."))

smlua_text_utils_dialog_replace(DIALOG_017,1,4,30,200, ("BIG BAB AMB"))

smlua_text_utils_dialog_replace(DIALOG_018,1,5,30,200, ("Just a quick heads-up \
about finding green\
stars in this polar site: \
don't try and look for \
one inside the temple.\
I've heard news about \
navigating it then not\
leaving back in time\
was a nightmare for\
treasure hunters so\
imagine the picture...\
we can't help but fear\
having another loss on\
the run, can't we?"))

smlua_text_utils_dialog_replace(DIALOG_019,1,4,30,200, ("Credits goes to:\
\
・ Lugmillord ・ \
Original hack & models\
・ Pilzinsel64 ・ \
SM64 ROM Manager\
・ Skelux ・ \
Music ports\
・ SMWCentral ・ \
Music ports & textures\
・ Nintendo ・ \
Original game\
Thanks to:\
Ozsef (aka Ozzie) for \
playtesting and making\
this edit with me :)\
Shoutouts to:\
The Crashers and \
the SM64 RHC Discord\
for all their support.\
And to YOU, the player, \
for playing the game.\
Enjoy! :)"))

smlua_text_utils_dialog_replace(DIALOG_020,1,6,95,150, (""))

smlua_text_utils_dialog_replace(DIALOG_021,1,2,95,200, ("Hey! You're not supposed\
to be here yet!"))

smlua_text_utils_dialog_replace(DIALOG_022,1,2,95,200, ("Nice try, pal. But this\
door will stay locked."))

smlua_text_utils_dialog_replace(DIALOG_023,1,3,95,200, (""))

smlua_text_utils_dialog_replace(DIALOG_024,1,5,95,200, (""))

smlua_text_utils_dialog_replace(DIALOG_025,1,5,95,200, (""))

smlua_text_utils_dialog_replace(DIALOG_026,1,4,95,200, (""))

smlua_text_utils_dialog_replace(DIALOG_027,1,4,95,200, (""))

smlua_text_utils_dialog_replace(DIALOG_028,1,3,95,200, (""))

smlua_text_utils_dialog_replace(DIALOG_029,1,5,95,200, (""))

smlua_text_utils_dialog_replace(DIALOG_030,1,4,30,200, ("Nice view, isn't it? \
We don't get exciting\
sensations around here \
today.\
But if you want, I can\
show you something \
worth the time. Here,\
just stand still on me."))

smlua_text_utils_dialog_replace(DIALOG_031,1,5,30,200, (""))

smlua_text_utils_dialog_replace(DIALOG_032,1,4,30,200, ("....You greedy fool.\
I guess you came here\
for two reasons.\
\
You either missed the\
star or you must have \
thought I'd have one\
more here for free.\
Now you shall live on\
this square for the rest\
of your life!"))

smlua_text_utils_dialog_replace(DIALOG_033,1,6,30,200, (""))

smlua_text_utils_dialog_replace(DIALOG_034,1,4,30,200, ("Here lies Baseball,\
he vanished from Earth \
as witnesses saw him fall \
into a pit of eyeballs.\
Legend has it told that\
『the deeper is the pit, \
the endless is the fall』\
once looking down a pit.\
It is certain his soul \
became one with the cruel \
death-glaring eyeballs\
since. Never look down!"))

smlua_text_utils_dialog_replace(DIALOG_035,1,3,30,200, ("Remember when this had \
annoying firsties? Well \
guess which one had! \
Pull off at least one \
and you win the Star! \
\
Should you fail and you \
are forced to climb back \
up to do them again."))

smlua_text_utils_dialog_replace(DIALOG_036,1,5,30,200, ("Hm, this door wasn't \
there before...\
I wonder what could \
this be?"))

smlua_text_utils_dialog_replace(DIALOG_037,1,2,30,200, (""))

smlua_text_utils_dialog_replace(DIALOG_038,1,3,95,200, ("Reacting to the Star \
power, the door slowly\
opens."))

smlua_text_utils_dialog_replace(DIALOG_039,1,5,30,200, ("VE"))

smlua_text_utils_dialog_replace(DIALOG_040,1,3,30,200, ("VE"))

smlua_text_utils_dialog_replace(DIALOG_041,1,3,30,200, (""))

smlua_text_utils_dialog_replace(DIALOG_042,1,5,30,200, ("There is only one green\
star in this little play \
ground, but it can't be \
that well-hidden, is it?\
\
Also the entrance pipe\
to the Grandmaster's\
Goal is gone, so you might\
as well go find it within\
the Master Temple.\
(The time attack star\
will not spawn as well, \
hence the timer is off\
for now.)"))

smlua_text_utils_dialog_replace(DIALOG_043,1,6,30,200, ("Welcome to the \
SAVE POINT ROOM!\
This area is a little\
special made for the\
overworld stars to be \
saved properly.\
Since due to the game \
developers' not over-\
bearing their blunders\
to fix them (yes, you,\
Nintendorks), we had to\
compromise with this.\
So whenever you collect \
a green star, you are \
sent here and then to \
the second overworld \
since this area is capable \
to save your game.\
So go ahead and grab\
the save point star!\
(it will stay green as it\
doesn't count in the\
star total)"))

smlua_text_utils_dialog_replace(DIALOG_044,1,5,95,200, (""))

smlua_text_utils_dialog_replace(DIALOG_045,1,6,95,200, (""))

smlua_text_utils_dialog_replace(DIALOG_046,1,5,30,200, ("Before you start, the\
green stars have \
different difficulties\
depending on how far \
you go in the gauntlet.\
For example, green\
stars at the start will \
be harder and some\
near the end will be \
easier.\
However: one issue is \
that you have to redo \
this level from the very \
start, so be prepared, \
you have been warned!\
Also, there are 4 green\
stars in this level, one \
of them in each segment. \
Keep your eyes peeled \
in finding them!"))

smlua_text_utils_dialog_replace(DIALOG_047,1,2,95,200, ("Bob-omblast Corp. at\
your service!"))

smlua_text_utils_dialog_replace(DIALOG_048,1,3,30,200, ("Hold it! \
."))

smlua_text_utils_dialog_replace(DIALOG_049,1,4,30,200, ("Watch out! \
Keep off the green bog \
or you will drown!\
I meant it. Literally!"))

smlua_text_utils_dialog_replace(DIALOG_050,1,5,30,200, ("Oh, hi. We meet again. \
How am I still in here, \
you ask? Well, it's hard \
to say but beyond any\
doubt, I like this place.\
Life in this 『town』 isn't\
so bad... If you were on \
my signs, I'd say get\
used to it. Wise words\
from the last resident.\
So hear me out, I saw\
a green shine flew by\
and it dropped to some\
place uphill. Is it going to\
turn town into Mars?"))

smlua_text_utils_dialog_replace(DIALOG_051,1,4,30,200, (""))

smlua_text_utils_dialog_replace(DIALOG_052,1,5,30,200, ("Yikes!"))

smlua_text_utils_dialog_replace(DIALOG_053,1,4,30,200, ("This level is different\
depending on what star\
you pick. On Stars 1-3,\
you will start up here.\
Then, on Stars 4-5, \
you start at the bottom \
in order to collect new \
green stars.\
Star 3 only spawns \
on its own act because \
the water level triggers \
will be deactivated."))

smlua_text_utils_dialog_replace(DIALOG_054,1,5,30,200, ("WATERLESS MODE"))

smlua_text_utils_dialog_replace(DIALOG_055,1,4,30,200, (""))

smlua_text_utils_dialog_replace(DIALOG_056,1,6,30,200, (""))

smlua_text_utils_dialog_replace(DIALOG_057,1,4,30,200, ("Help! My baby!"))

smlua_text_utils_dialog_replace(DIALOG_058,1,5,30,200, (""))

smlua_text_utils_dialog_replace(DIALOG_059,1,5,30,200, (""))

smlua_text_utils_dialog_replace(DIALOG_060,1,5,30,200, ("If you know nothing \
about Super Mario 74, \
then you must be out\
of your mind if you\
haven't played it!\
Same for green comet\
hacks, best examples\
are SM64 The Green \
Comet or Star Road: \
Green Comet. \
So what are you waiting\
for? Go get yourself \
ready in both of these \
green hunt fests!"))

smlua_text_utils_dialog_replace(DIALOG_061,1,5,30,200, ("This hack comes with \
a display layout. Use it \
to track down the stars \
to your advantage. \
\
Levels don't have all 7\
stars each, but it's\
better than nothing\
as dropping quantity\
sometimes."))

smlua_text_utils_dialog_replace(DIALOG_062,1,3,30,200, ("You've hit the midway\
point! Don't give up! \
You're almost there!"))

smlua_text_utils_dialog_replace(DIALOG_063,1,5,30,200, ("Don't pay attention to\
the sudden skybox\
change. It's because this \
segment and the previous\
one are replicas. \
I ran out of areas in the \
same level since it is \
really long. It had to be \
done for the green stars' \
sake. \
If you die, you will be \
put back at the end of \
the previous area. That \
also applies to all past \
the first segment."))

smlua_text_utils_dialog_replace(DIALOG_064,1,5,30,200, ("Strong wind ahead!\
Don't get blown away!"))

smlua_text_utils_dialog_replace(DIALOG_065,1,4,30,200, ("Welcome back to the\
abandoned factory. \
This hasn't changed\
much like last time.\
The only thing that is\
different here is that\
there is no more cap\
boxes spawned. \
Do your best finding \
green stars without them."))

smlua_text_utils_dialog_replace(DIALOG_066,1,5,30,200, (""))

smlua_text_utils_dialog_replace(DIALOG_067,1,5,30,200, ("KEY 1"))

smlua_text_utils_dialog_replace(DIALOG_068,1,4,30,200, ("Caution!\
On Stars 1-3, the Wing\
Cap is not available.\
\
It will pop up as soon \
as you select Star 4.\
The wing cap will be in\
the same spot as before."))

smlua_text_utils_dialog_replace(DIALOG_069,1,4,30,200, ("Hi there, I'm Cutshort. \
If you happen to meet \
me randomly here, it's \
for one particular reason.\
You're looking for green\
stars, and this level is \
so hard to stand up \
to its fails and deaths.\
But you're in luck, I'm\
here to take you to a\
designated segment, but \
hear me out carefully.\
My ways require selecting \
a specific star act so a\
random door will show \
up in my stead.\
ACT 1: None\
ACT 2: Ancient door\
ACT 3: Castle door\
ACT 4: Metal door\
I can't guarantee what \
are the odds but my \
doors have never failed \
me no matter what."))

smlua_text_utils_dialog_replace(DIALOG_070,1,5,30,200, ("Believe it or not, but the \
spot underneath you is \
terrible. Try which side \
works the best for you \
with the D-pad cam.\
If your angle is accurate\
to the wall, then longjump \
back down, wallkick \
and aim for the ledge \
as hard as you can."))

smlua_text_utils_dialog_replace(DIALOG_071,1,4,30,200, ("I have to admit, this \
green star on the roof \
up there is quite the \
pickle to get to...\
At least there's one \
catch to this: learning \
skill with angled jumps!\
\
Did you know that\
combining a triple \
jump and a wall kick \
on 45 degree angles, \
all the while as pulling\
back over the ledge,\
you can reach up near \
high surfaces?\
Yes, that is proven as\
true! Use this rooftop to\
try out your practices. \
\
That is, if you manage\
to get it down without \
grabbing the ledge or \
slipping off the roof."))

smlua_text_utils_dialog_replace(DIALOG_072,1,5,30,200, ("Quick word of advice: \
I highly recommend you \
practice this level's stars \
with savestates before \
you attempt them."))

smlua_text_utils_dialog_replace(DIALOG_073,1,4,95,200, ("Note: since this level is \
split in two sides, green \
stars will have a label \
next to their name.\
If it's -Wrath-, pick the\
pipe to your right.\
If it's -Pain-, pick the \
pipe to your left.\
However, you're free to\
go in which side at any\
order you want."))

smlua_text_utils_dialog_replace(DIALOG_074,1,6,30,200, ("Trust me, this star isn't\
as simple as you may \
think. \
\
To get there, you have \
to have to do some \
teamwork with the \
enemy.\
\
This Big Boo is here to \
do the job! For this, you\
have to do SimpleFlips'\
most infamous Boo strat\
as shown in Star Road!\
To help you out, get\
yourself lined up face\
to face toward the\
pillars, then make the\
Big Boo come at you\
facing one of the pillars\
(front or back works),\
and finally, start your \
bounces with a long\
jump.\
If Big Boo's alignment's\
off, start over. If you \
attack him once, start \
over. If you screw up or\
take too long, start over.\
Don't bother defeating \
Big Boo and get his star\
either, this one is only\
a decoy.\
\
Also the star so far off \
the distance from here, \
just believe in yourself \
and go forward!"))

smlua_text_utils_dialog_replace(DIALOG_075,1,5,30,200, ("It's summer time!"))

smlua_text_utils_dialog_replace(DIALOG_076,1,5,30,200, ("TOAD 1"))

smlua_text_utils_dialog_replace(DIALOG_077,1,4,150,200, ("What? You've never seen\
a Toad use his mystic\
powers to float 3 inches\
above water? Foolish!\
I'll have you know I was \
recognized by a world-\
renowned circus just by \
this ability! You'll see!"))

smlua_text_utils_dialog_replace(DIALOG_078,1,5,30,200, ("."))

smlua_text_utils_dialog_replace(DIALOG_079,1,4,30,200, (""))

smlua_text_utils_dialog_replace(DIALOG_080,1,5,95,200, ("monkeyS"))

smlua_text_utils_dialog_replace(DIALOG_081,1,6,30,200, ("STAR MARKER"))

smlua_text_utils_dialog_replace(DIALOG_082,1,5,30,200, ("TOAD 2"))

smlua_text_utils_dialog_replace(DIALOG_083,1,5,30,200, ("TOAD 3"))

smlua_text_utils_dialog_replace(DIALOG_084,1,4,30,200, ("MIPS 1"))

smlua_text_utils_dialog_replace(DIALOG_085,1,5,30,200, ("These machines are \
suspicious. They never \
were able to shoot \
anything or come in \
handy on the defense.\
I guess something went\
bad with them to work? \
How about you check \
out? At least they don't \
do harm at all."))

smlua_text_utils_dialog_replace(DIALOG_086,1,4,30,200, ("C13"))

smlua_text_utils_dialog_replace(DIALOG_087,1,5,30,200, ("C14"))

smlua_text_utils_dialog_replace(DIALOG_088,1,5,30,200, ("C15"))

smlua_text_utils_dialog_replace(DIALOG_089,1,5,30,200, ("B3"))

smlua_text_utils_dialog_replace(DIALOG_090,1,5,30,200, ("KEY 1"))

smlua_text_utils_dialog_replace(DIALOG_091,2,3,30,200, ("Wow, I can't believe you\
actually came up here\
just for little ol' me.\
You really know how to\
make a sign feel special."))

smlua_text_utils_dialog_replace(DIALOG_092,1,5,30,200, ("KEY 2"))

smlua_text_utils_dialog_replace(DIALOG_093,1,5,30,200, ("BOWSER"))

smlua_text_utils_dialog_replace(DIALOG_094,1,4,30,200, ("SR3 is the best oldschool \
Star Revenge! It's just \
so great! I don't get why\
people don't like it-\
(The rest of the paper \
is missing. You wonder \
who took it...)"))

smlua_text_utils_dialog_replace(DIALOG_095,1,5,30,200, ("Yo, it's LinCrash.\
Oh hey, it's you again?\
I didn't think you'd\
get this far to appear\
one more time here.\
I guess you've had enough \
of this hack, right?\
Yes? No? I guess you \
don't care less than\
just beat it, huh.\
Well I don't have a\
fantastic award to give\
you but here are my \
sentiments.\
\
Congrats, god gamer.\
You have proven your\
worth with skill, once \
and for all. May you\
receive a big A.\
This star will act as the \
end screen. No picture \
because the game freezes \
after you grab it. And \
with that, Lincrash out."))

smlua_text_utils_dialog_replace(DIALOG_096,1,2,30,200, ("Want the greatest emote \
for your Twitch chat? \
Get Bleh into your\
emote list today! Bleh\
For real tho, add Bleh."))

smlua_text_utils_dialog_replace(DIALOG_097,1,4,30,200, ("Here lies Viper, \
he got turned into a \
sign from a sign curse \
against his will. \
Traces of him are still \
unknown. Records say \
his hacks were a bad \
sign of game design."))

smlua_text_utils_dialog_replace(DIALOG_098,1,4,95,200, ("Here lies Fritfrat,\
one of the supreme OG\
runners in extreme \
SM64 ROM hack history.\
His comeback to replay \
NoD one more time yet \
remains a mystery for \
years to come."))

smlua_text_utils_dialog_replace(DIALOG_099,1,5,95,200, ("It's a disaster!"))

smlua_text_utils_dialog_replace(DIALOG_100,1,3,95,200, ("This fence is, unlike the\
rest, is not trespassable \
with the Vanish Cap. \
Instead, you need a more \
bizarre means to get \
through it, but where?"))

smlua_text_utils_dialog_replace(DIALOG_101,1,3,95,200, (""))

smlua_text_utils_dialog_replace(DIALOG_102,1,3,30,200, ("Here lies Ketchupyoshi,\
the real OG of the OGs, \
the true G in the sh☆t.\
Gone too soon from \
drowning in a sea full\
of beer. What a tragedy."))

smlua_text_utils_dialog_replace(DIALOG_103,1,4,95,200, ("Here lies a bearcat,\
gone from losing runs \
over a plumber being so\
desperate to die choking."))

smlua_text_utils_dialog_replace(DIALOG_104,1,3,30,200, (""))

smlua_text_utils_dialog_replace(DIALOG_105,1,3,95,200, (""))

smlua_text_utils_dialog_replace(DIALOG_106,1,2,95,200, ("That'll be 5 coins. Thanks \
for your patronage."))

smlua_text_utils_dialog_replace(DIALOG_107,1,4,95,200, (""))

smlua_text_utils_dialog_replace(DIALOG_108,1,3,95,200, (""))

smlua_text_utils_dialog_replace(DIALOG_109,1,5,95,200, ("Just in case you forgot, \
this warp pad skips the\
walljump fortress section. \
It will only activate on \
Stars 4-5."))

smlua_text_utils_dialog_replace(DIALOG_110,1,4,95,200, ("The warp pad leading\
to the fallen fortress\
will activate on Star 3 \
and onwards."))

smlua_text_utils_dialog_replace(DIALOG_111,1,4,95,200, ("BLJ funtimes! \
See these little green\
stars at the horizon?\
 \
Go under the wall and \
mash 'til you start \
soaring through the sky \
like a bird.\
Don't worry about \
missing the star. They \
line up along that wall \
just to help you out \
in case you have a bad \
angle. They all share \
the same ID, too!"))

smlua_text_utils_dialog_replace(DIALOG_112,1,2,30,200, ("It always feels like \
somebody's watching me..."))

smlua_text_utils_dialog_replace(DIALOG_113,1,5,30,200, ("This sign is where sleeps\
a speedy young goat. \
Faint keyboard thumping \
sounds can be heard as \
you read this text."))

smlua_text_utils_dialog_replace(DIALOG_114,1,5,95,200, ("WHOMPER"))

smlua_text_utils_dialog_replace(DIALOG_115,1,5,95,200, (""))

smlua_text_utils_dialog_replace(DIALOG_116,1,5,95,200, ("NO WAY!"))

smlua_text_utils_dialog_replace(DIALOG_117,1,5,95,200, ("EYEROCK"))

smlua_text_utils_dialog_replace(DIALOG_118,1,5,95,200, (""))

smlua_text_utils_dialog_replace(DIALOG_119,1,6,30,200, (""))

smlua_text_utils_dialog_replace(DIALOG_120,1,4,30,200, (""))

smlua_text_utils_dialog_replace(DIALOG_121,1,5,30,200, ("Impossible!"))

smlua_text_utils_dialog_replace(DIALOG_122,1,4,30,200, ("C14"))

smlua_text_utils_dialog_replace(DIALOG_123,1,4,30,200, ("The 『Kubus of Hope』."))

smlua_text_utils_dialog_replace(DIALOG_124,1,4,30,200, ("C15"))

smlua_text_utils_dialog_replace(DIALOG_125,1,4,30,200, ("The 『Kubus of Despair』."))

smlua_text_utils_dialog_replace(DIALOG_126,2,6,30,200, ("MDP"))

smlua_text_utils_dialog_replace(DIALOG_127,3,1,30,200, ("...\
...\
Oh hi Viper :)"))

smlua_text_utils_dialog_replace(DIALOG_128,1,4,95,200, ("HA! That was useless!"))

smlua_text_utils_dialog_replace(DIALOG_129,1,4,30,200, ("Here lies KingToad,\
he was the 『Wario\
number 1』 fan. And a \
74EE addict as well.\
Last words we heard\
of him from were:\
\
『...PRChase.』"))

smlua_text_utils_dialog_replace(DIALOG_130,1,3,30,200, ("Here lies Katze789,\
he died from a super \
kaizo overdose.\
No one truly knows if \
that was accidental.\
May he rest in pain."))

smlua_text_utils_dialog_replace(DIALOG_131,1,4,30,200, ("Here lies Bigfoot,\
he died from being \
touched by a real bigfoot \
while playing rando. \
Records alledgedly say \
the bigfoot was Big \
Chungus, an entity \
worshipped when brb'd."))

smlua_text_utils_dialog_replace(DIALOG_132,1,4,30,200, (""))

smlua_text_utils_dialog_replace(DIALOG_133,1,5,30,200, ("It's been a while since\
you have showed up\
here, Mario. I assume\
you got back after\
hearing the news...\
A green comet struck\
by last night which made\
green stars flee into\
the worlds! I saw them\
in my own eyes!\
I would try to go search\
them myself but turns\
out I can't jump high\
like you do.\
\
Please, can you take \
care of that for me? \
Thanks! I knew I could\
count on you!"))

smlua_text_utils_dialog_replace(DIALOG_134,1,5,30,200, ("Readings tell me that\
green stars dropped \
into this painting! \
Be careful when sneaking\
into them, though. \
They might not make \
any noise, but they can\
be a handful when \
looking after around \
places you don't see."))

smlua_text_utils_dialog_replace(DIALOG_135,1,5,30,200, ("Hrrumph!\
If only I didn't ditch\
class on leg exercises,\
I wouldn't've had it bad \
pulling my muscle!\
Wko knew kicking and \
pounding up slopes were \
a terrible idea?!"))

smlua_text_utils_dialog_replace(DIALOG_136,1,5,30,200, ("This star up there... \
I can't even point my \
finger how to reach it. \
Do you have any idea? \
\
This looks like veeeryyy\
feasible to make up \
with more than one \
super jump.\
\
Think this world has\
more challenges up its \
sleeve to test you, but \
I'm sure you would be \
VERY fiiiine..."))

smlua_text_utils_dialog_replace(DIALOG_137,1,5,30,200, ("Now that Bowser's shell\
out of luck, opening\
doors with stars are \
irrevelant. The world is\
saved after all.\
Every world you go to\
is free from their seal,\
but that doesn't mean\
they aren't affected by\
the changes.\
They also depend on the\
star act you choose, so \
pay attention to that \
before you enter them."))

smlua_text_utils_dialog_replace(DIALOG_138,1,4,30,200, ("Hey, you're looking a bit\
stressed. Why don't you\
take a sit here and have\
a short break?\
There you go. Take 5 \
minutes to enjoy the \
view, listen to chill beats,\
or talk to just... relax."))

smlua_text_utils_dialog_replace(DIALOG_139,1,4,30,200, ("TG1"))

smlua_text_utils_dialog_replace(DIALOG_140,1,5,30,200, ("TG2"))

smlua_text_utils_dialog_replace(DIALOG_141,1,4,150,200, ("Oh boy! You got a \
green star! Amazing!\
Such a god gaming act\
right there!\
No, seriously that's\
pretty lame, maybe \
you should try harder \
next time."))

smlua_text_utils_dialog_replace(DIALOG_142,1,6,150,200, ("Really...? \
Is this all you can do \
for 5 cheap stars? \
I feel like pony games \
are more your thing \
than mad skills..."))

smlua_text_utils_dialog_replace(DIALOG_143,1,5,150,200, ("With such an amount, \
we're barely touching \
the 50 percent of the \
game! Even Katze will \
be shocked to hear this!"))

smlua_text_utils_dialog_replace(DIALOG_144,1,3,150,200, ("Halfway there, are we?\
Mmm yeah, you're doing\
good on the progress.\
(...Can't believe I'm \
praising a scrub of all \
people...)"))

smlua_text_utils_dialog_replace(DIALOG_145,1,4,150,200, ("Oh boy! Can you feel\
the tension? Don't you\
feel that you are close,\
but don't? \
Quite a shame, I've \
started to like you a\
bit, and the adventure\
has just begun to end."))

smlua_text_utils_dialog_replace(DIALOG_146,1,5,150,200, ("Well, I'm impressed. \
You've gotten all 101 \
green stars.\
Just wow. I could not \
have done better there. \
Give yourself a pat on \
the back. But next time \
I won't go easy on you,\
you dope gaming freak!\
\
So yeah, your reward\
awaits behind that\
mysterious door.\
Congratulations."))

smlua_text_utils_dialog_replace(DIALOG_147,1,5,30,200, ("Bowser's hidden up there!"))

smlua_text_utils_dialog_replace(DIALOG_148,1,4,30,200, ("B2"))

smlua_text_utils_dialog_replace(DIALOG_149,1,4,30,200, (""))

smlua_text_utils_dialog_replace(DIALOG_150,1,5,30,200, (""))

smlua_text_utils_dialog_replace(DIALOG_151,1,4,30,200, (""))

smlua_text_utils_dialog_replace(DIALOG_152,1,3,30,200, (""))

smlua_text_utils_dialog_replace(DIALOG_153,1,5,30,200, ("HeaveHi"))

smlua_text_utils_dialog_replace(DIALOG_154,1,5,30,200, ("TOAD 2"))

smlua_text_utils_dialog_replace(DIALOG_155,1,4,30,200, ("TOAD 1"))

smlua_text_utils_dialog_replace(DIALOG_156,1,5,30,200, ("TOAD 3"))

smlua_text_utils_dialog_replace(DIALOG_157,1,6,30,200, ("B3"))

smlua_text_utils_dialog_replace(DIALOG_158,1,5,30,200, ("Welcome back.\
This place is a bit \
different than before.\
\
\
First off, the cannon is\
now open the last time \
you came since, so you \
get spared from the\
reclimb madness.\
Secondly, the cap boxes\
are gone as they are no \
longer needed for the \
green stars here."))

smlua_text_utils_dialog_replace(DIALOG_159,1,6,30,200, ("ketchup13Paint"))

smlua_text_utils_dialog_replace(DIALOG_160,1,4,30,200, ("There's no green stars\
past this point.\
Turn back now. \
...Or is it?"))

smlua_text_utils_dialog_replace(DIALOG_161,1,4,30,200, ("YOSHI"))

smlua_text_utils_dialog_replace(DIALOG_162,1,5,30,200, ("MIPS 2"))

smlua_text_utils_dialog_replace(DIALOG_163,1,5,30,200, ("GG B3"))

smlua_text_utils_dialog_replace(DIALOG_164,1,4,30,200, (""))

smlua_text_utils_dialog_replace(DIALOG_165,1,5,30,200, ("I'm still amazed you're\
able to return here\
for many years.\
So... welcome back."))

smlua_text_utils_dialog_replace(DIALOG_166,1,4,30,200, ("CG2"))

smlua_text_utils_dialog_replace(DIALOG_167,1,3,30,200, ("CG3"))

smlua_text_utils_dialog_replace(DIALOG_168,1,5,30,200, (""))

smlua_text_utils_dialog_replace(DIALOG_169,1,5,30,200, ("CG4"))

