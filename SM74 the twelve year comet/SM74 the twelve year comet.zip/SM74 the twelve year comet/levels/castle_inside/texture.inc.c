ALIGNED8 u8 castle_inside_1__texture_0E000018[] = {
#include "levels/castle_inside/castle_inside_1_0xe000018_custom.rgba32.inc.c"
};
ALIGNED8 u8 castle_inside_1__texture_0E001820[] = {
#include "levels/castle_inside/castle_inside_1_0xe001820_custom.rgba32.inc.c"
};
ALIGNED8 u8 castle_inside_1__texture_0E001020[] = {
#include "levels/castle_inside/castle_inside_1_0xe001020_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_inside_1__texture_0E002820[] = {
#include "levels/castle_inside/castle_inside_1_0xe002820_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_inside_1__texture_0E004020[] = {
#include "levels/castle_inside/castle_inside_1_0xe004020_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_inside_1__texture_0E008820[] = {
#include "levels/castle_inside/castle_inside_1_0xe008820_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_inside_1__texture_0E009020[] = {
#include "levels/castle_inside/castle_inside_1_0xe009020_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_inside_1__texture_0E007820[] = {
#include "levels/castle_inside/castle_inside_1_0xe007820_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_inside_1__texture_0E006820[] = {
#include "levels/castle_inside/castle_inside_1_0xe006820_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_inside_1__texture_0E018820[] = {
#include "levels/castle_inside/castle_inside_1_0xe018820_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_inside_1__texture_0E005820[] = {
#include "levels/castle_inside/castle_inside_1_0xe005820_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_inside_1__texture_0E010820[] = {
#include "levels/castle_inside/castle_inside_1_0xe010820_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_inside_1__texture_0E010020[] = {
#include "levels/castle_inside/castle_inside_1_0xe010020_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_inside_1__texture_0E00C820[] = {
#include "levels/castle_inside/castle_inside_1_0xe00c820_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_inside_1__texture_0E00A020[] = {
#include "levels/castle_inside/castle_inside_1_0xe00a020_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_inside_1__texture_0E013020[] = {
#include "levels/castle_inside/castle_inside_1_0xe013020_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_inside_1__texture_0E004820[] = {
#include "levels/castle_inside/castle_inside_1_0xe004820_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_inside_1__texture_0E00D820[] = {
#include "levels/castle_inside/castle_inside_1_0xe00d820_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_inside_1__texture_0E006020[] = {
#include "levels/castle_inside/castle_inside_1_0xe006020_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_inside_1__texture_0E00C020[] = {
#include "levels/castle_inside/castle_inside_1_0xe00c020_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_inside_1__texture_0E016820[] = {
#include "levels/castle_inside/castle_inside_1_0xe016820_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_inside_1__texture_0E017020[] = {
#include "levels/castle_inside/castle_inside_1_0xe017020_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_inside_1__texture_0E007020[] = {
#include "levels/castle_inside/castle_inside_1_0xe007020_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_inside_1__texture_0E015020[] = {
#include "levels/castle_inside/castle_inside_1_0xe015020_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_inside_1__texture_0E005020[] = {
#include "levels/castle_inside/castle_inside_1_0xe005020_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_inside_1__texture_0E009820[] = {
#include "levels/castle_inside/castle_inside_1_0xe009820_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_inside_1__texture_0E008020[] = {
#include "levels/castle_inside/castle_inside_1_0xe008020_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_inside_1__texture_0E00D020[] = {
#include "levels/castle_inside/castle_inside_1_0xe00d020_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_inside_1__texture_0E016020[] = {
#include "levels/castle_inside/castle_inside_1_0xe016020_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_inside_1__texture_0E011020[] = {
#include "levels/castle_inside/castle_inside_1_0xe011020_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_inside_1__texture_0E00E020[] = {
#include "levels/castle_inside/castle_inside_1_0xe00e020_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_inside_1__texture_0E011820[] = {
#include "levels/castle_inside/castle_inside_1_0xe011820_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_inside_1__texture_0E00F820[] = {
#include "levels/castle_inside/castle_inside_1_0xe00f820_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_inside_1__texture_0E014020[] = {
#include "levels/castle_inside/castle_inside_1_0xe014020_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_inside_1__texture_0E012020[] = {
#include "levels/castle_inside/castle_inside_1_0xe012020_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_inside_1__texture_0E003820[] = {
#include "levels/castle_inside/castle_inside_1_0xe003820_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_inside_1__texture_0E00A820[] = {
#include "levels/castle_inside/castle_inside_1_0xe00a820_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_inside_1__texture_0E015820[] = {
#include "levels/castle_inside/castle_inside_1_0xe015820_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_inside_1__texture_0E012820[] = {
#include "levels/castle_inside/castle_inside_1_0xe012820_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_inside_1__texture_0E013820[] = {
#include "levels/castle_inside/castle_inside_1_0xe013820_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_inside_1__texture_0E00F020[] = {
#include "levels/castle_inside/castle_inside_1_0xe00f020_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_inside_1__texture_0E00E820[] = {
#include "levels/castle_inside/castle_inside_1_0xe00e820_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_inside_1__texture_0E00B820[] = {
#include "levels/castle_inside/castle_inside_1_0xe00b820_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_inside_1__texture_0E00B020[] = {
#include "levels/castle_inside/castle_inside_1_0xe00b020_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_inside_1__texture_0E017820[] = {
#include "levels/castle_inside/castle_inside_1_0xe017820_custom.rgba16.inc.c"
};
