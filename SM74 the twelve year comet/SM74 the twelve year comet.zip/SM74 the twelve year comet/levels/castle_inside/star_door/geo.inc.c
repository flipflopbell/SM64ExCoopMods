// 0x0E000F00
const GeoLayout castle_geo_000F00[] = {
   GEO_CULLING_RADIUS(400),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, inside_castle_seg7_dl_0703BFA8),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
