// 0x070777EC - 0x0707782A
const MacroObject inside_castle_seg7_area_3_macro_objs[] = {
    MACRO_OBJECT_WITH_BEH_PARAM(/*preset*/ macro_sign_on_wall,       /*yaw*/   0, /*pos*/  6400, -1178, -1270, /*behParam*/ DIALOG_077),
    MACRO_OBJECT(/*preset*/ macro_hidden_1up_trigger, /*yaw*/   0, /*pos*/  2130, -2508,  -946),
    MACRO_OBJECT(/*preset*/ macro_hidden_1up_trigger, /*yaw*/   0, /*pos*/  2130, -2508,   -92),
    MACRO_OBJECT(/*preset*/ macro_hidden_1up_trigger, /*yaw*/   0, /*pos*/  3515, -2508,  -946),
    MACRO_OBJECT(/*preset*/ macro_hidden_1up_trigger, /*yaw*/   0, /*pos*/  3515, -2508,   -92),
    MACRO_OBJECT_WITH_BEH_PARAM(/*preset*/ macro_hidden_1up,         /*yaw*/   0, /*pos*/  2861, -2508,  -515, /*behParam*/ 4),
    MACRO_OBJECT_END(),
};
