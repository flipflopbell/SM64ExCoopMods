// 0x070777E0 - 0x070777EC
const MacroObject inside_castle_seg7_area_2_macro_objs[] = {
    MACRO_OBJECT_WITH_BEH_PARAM(/*preset*/ macro_sign_on_wall,       /*yaw*/  90, /*pos*/   164,  1203,  2278, /*behParam*/ DIALOG_019),
    MACRO_OBJECT_END(),
};
