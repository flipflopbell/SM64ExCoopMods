// 0x0E001940
const GeoLayout castle_geo_001940[] = {
   GEO_CULLING_RADIUS(550),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, inside_castle_seg7_dl_07068B10),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
