smlua_text_utils_course_acts_replace(COURSE_BOB, (" 1 DICE DOMAIN"),	("GREEN STAR 1"),	("GREEN STAR 2"),	("GREEN STAR 3"),	("GREEN STAR 4"),	("CLEARED!"),	(""))

smlua_text_utils_course_acts_replace(COURSE_WF, (" 2 CONCRETE JUNGLE"),	("GREEN STAR 1"),	("GREEN STAR 2"),	("GREEN STAR 3"),	("GREEN STAR 4"),	("GREEN STAR 5"),	("CLEARED!"))

smlua_text_utils_course_acts_replace(COURSE_JRB, (" 3 WALLOWING WELLS"),	("GREEN STAR 1"),	("GREEN STAR 2"),	("GREEN STAR 3"),	("GREEN STAR 4"),	("GREEN STAR 5"),	("CLEARED!"))

smlua_text_utils_course_acts_replace(COURSE_CCM, (" 4 BOGEY BAYOU"),	("GREEN STAR 1"),	("GREEN STAR 2"),	("GREEN STAR 3"),	("CLEARED!"),	(""),	(""))

smlua_text_utils_course_acts_replace(COURSE_BBH, (" 5 FLAMEWORK FACTORY"),	("GREEN STAR 1"),	("GREEN STAR 2"),	("GREEN STAR 3"),	("GREEN STAR 4"),	("CLEARED!"),	(""))

smlua_text_utils_course_acts_replace(COURSE_HMC, (" 6 STALACTITE CAVE"),	("GREEN STAR 1"),	("GREEN STAR 2"),	("GREEN STAR 3"),	("CLEARED!"),	(""),	(""))

smlua_text_utils_course_acts_replace(COURSE_LLL, (" 7 CRUMBLE RUMBLE TOWER"),	("GREEN STAR 1"),	("GREEN STAR 2"),	("GREEN STAR 3"),	("GREEN STAR 4"),	("CLEARED!"),	(""))

smlua_text_utils_course_acts_replace(COURSE_SSL, (" 8 ABSOLUTE ZEROASIS"),	("GREEN STAR 1"),	("GREEN STAR 2"),	("GREEN STAR 3"),	("GREEN STAR 4"),	("CLEARED!"),	(""))

smlua_text_utils_course_acts_replace(COURSE_DDD, (" 9 NATURE NOCTURNE"),	("GREEN STAR 1"),	("GREEN STAR 2"),	("GREEN STAR 3"),	("GREEN STAR 4"),	("GREEN STAR 5"),	("CLEARED!"))

smlua_text_utils_course_acts_replace(COURSE_SL, ("10 QUICKSAND BEACH"),	("GREEN STAR 1"),	("GREEN STAR 2"),	("GREEN STAR 3"),	("GREEN STAR 4"),	("GREEN STAR 5"),	("CLEARED!"))

smlua_text_utils_course_acts_replace(COURSE_WDW, ("11 POLLUTED POND"),	("GREEN STAR 1"),	("GREEN STAR 2"),	("GREEN STAR 3"),	("GREEN STAR 4"),	("CLEARED!"),	(""))

smlua_text_utils_course_acts_replace(COURSE_TTM, ("12 CLIFF OF TIME"),	("GREEN STAR 1 -WRATH-"),	("GREEN STAR 2 -WRATH-"),	("GREEN STAR 3 -WRATH-"),	("GREEN STAR 4 -PAIN-"),	("GREEN STAR 5 -PAIN-"),	("GREEN STAR 6 -PAIN-"))

smlua_text_utils_course_acts_replace(COURSE_THI, ("13 SEA SALT PEAKS"),	("GREEN STAR 1"),	("GREEN STAR 2"),	("GREEN STAR 3"),	("GREEN STAR 4"),	("CLEARED!"),	(""))

smlua_text_utils_course_acts_replace(COURSE_TTC, ("14 VENINIUM-SPHERE"),	("GREEN STAR 1"),	("GREEN STAR 2"),	("GREEN STAR 3"),	("GREEN STAR 4"),	("GREEN STAR 5"),	("CLEARED!"))

smlua_text_utils_course_acts_replace(COURSE_RR, ("15 DELOMBRU-SPHERE"),	("GREEN STAR 1"),	("GREEN STAR 2"),	("GREEN STAR 3"),	("GREEN STAR 4"),	("CLEARED!"),	(""))

smlua_text_utils_secret_star_replace(15 + 1, ("   BOWSER'S PARK PARTY"))
smlua_text_utils_secret_star_replace(16 + 1, ("   BOWSER'S TIDAL TROPICS"))
smlua_text_utils_secret_star_replace(17 + 1, ("   BOWSER'S RAINBOW REALM"))
smlua_text_utils_secret_star_replace(18 + 1, ("   UNDERGROUND SLIDE"))
smlua_text_utils_secret_star_replace(19 + 1, ("   AERIAL ALPINE"))
smlua_text_utils_secret_star_replace(20 + 1, ("   LAVA PIT OF INVERSION"))
smlua_text_utils_secret_star_replace(21 + 1, ("   DUSTY DARKNESS"))
smlua_text_utils_secret_star_replace(22 + 1, ("   TRAINING GROUNDS"))
smlua_text_utils_secret_star_replace(23 + 1, ("   VOID OF THE EAST"))
smlua_text_utils_secret_star_replace(24 + 1, ("   GRANDMASTER'S GOAL"))
smlua_text_utils_castle_secret_stars_replace(("   BONUS GREEN STARS"))
smlua_text_utils_extra_text_replace(0,("YOU GOT A BONUS GREEN STAR!"))
smlua_text_utils_extra_text_replace(1,(""))
smlua_text_utils_extra_text_replace(2,(""))
smlua_text_utils_extra_text_replace(3,(""))
smlua_text_utils_extra_text_replace(4,(""))
smlua_text_utils_extra_text_replace(5,(""))
smlua_text_utils_extra_text_replace(6,(""))
