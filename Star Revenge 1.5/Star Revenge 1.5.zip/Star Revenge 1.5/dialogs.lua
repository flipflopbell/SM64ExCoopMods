smlua_text_utils_dialog_replace(DIALOG_000,1,6,30,200, ("Beware, an invi wall\
could be ahead."))

smlua_text_utils_dialog_replace(DIALOG_001,1,4,95,200, ("Come back here when\
you got star 1 to 4\
and a wing cap box\
will be up here."))

smlua_text_utils_dialog_replace(DIALOG_002,1,4,95,200, ("Sorry, I won't open\
you the cannons now!\
Show me that you got\
the first 5 stars\
and I will open them.\
Then you can also find\
wing caps around them."))

smlua_text_utils_dialog_replace(DIALOG_003,1,6,95,200, ("Oh hey there! Wanna\
know a secret?\
The blue tower which\
has overworld 3 inside\
it has another secret.\
You see when you go\
behind it you can\
walljump up to a\
vanish cap. You can\
use that cap to get\
to 2 more levels you\
haven't been in!"))

smlua_text_utils_dialog_replace(DIALOG_004,1,3,95,200, ("ok..."))

smlua_text_utils_dialog_replace(DIALOG_005,1,5,30,200, ("Well hello there\
Mario. What brings\
you here? I'm trying\
to find a way to break\
the seal of this\
temple so that I can\
explore it. Well...\
The sprit of this\
place did a way to\
good job on this...\
Anyway, guess you\
want one of my stars?\
Race me to the water-\
fall and I give you\
one for winning!\
Ready...\
\
//Go!////Don't Go"))

smlua_text_utils_dialog_replace(DIALOG_006,1,3,30,200, ("Hey!!! Don't try to scam\
ME. You've gotta run\
the whole course.\
Later. Look me up when\
you want to race for\
real."))

smlua_text_utils_dialog_replace(DIALOG_007,1,5,30,200, ("Oh well. I think I\
need a big idiot to\
break this seal.\
\
But something I\
noticed is that one\
of the trees here\
seems strange, but\
that's not my prob."))

smlua_text_utils_dialog_replace(DIALOG_008,1,4,30,200, ("8"))

smlua_text_utils_dialog_replace(DIALOG_009,1,5,30,200, ("Hey Mario! It's me\
koopa... well I\
found this shiny\
thing here... want\
it? Na, not so fast,\
first a race to...\
let's say the oasis.\
First to get there\
will keep the star!\
\
Ready?\
\
//Go//// Don't Go"))

smlua_text_utils_dialog_replace(DIALOG_010,1,4,30,200, ("Would you like to Save?\
\
//Yes////No"))

smlua_text_utils_dialog_replace(DIALOG_011,1,4,30,200, ("Would you like to Save?\
\
//Yes////No"))

smlua_text_utils_dialog_replace(DIALOG_012,1,4,30,200, ("Would you like to Save?\
\
//Yes////No"))

smlua_text_utils_dialog_replace(DIALOG_013,1,4,30,200, ("You've collected 80\
coins! You know what\
that means?   YEP!\
No icecream for you!\
Save cake instead?\
\
//Yes////Ice I:"))

smlua_text_utils_dialog_replace(DIALOG_014,1,4,30,200, ("Do you want to Save?\
\
//You Bet//Not Now"))

smlua_text_utils_dialog_replace(DIALOG_015,1,4,30,200, ("15"))

smlua_text_utils_dialog_replace(DIALOG_016,1,3,30,200, ("16"))

smlua_text_utils_dialog_replace(DIALOG_017,1,4,30,200, ("I'm Prince Bob-omb,\
brother of King\
Bob-omb. What are\
you looking for in\
my peaceful valley?\
\
A star in blue? I\
have one of those.\
You want that star?\
Well then...\
\
    1 v 1 me m8!"))

smlua_text_utils_dialog_replace(DIALOG_018,1,4,30,200, ("18"))

smlua_text_utils_dialog_replace(DIALOG_019,1,2,30,200, ("19"))

smlua_text_utils_dialog_replace(DIALOG_020,1,6,95,150, ("gay"))

smlua_text_utils_dialog_replace(DIALOG_021,1,5,95,200, ("21"))

smlua_text_utils_dialog_replace(DIALOG_022,1,2,95,200, ("You need a key to open\
this door or [%] more\
stars, guess you know\
what kind of door it is!"))

smlua_text_utils_dialog_replace(DIALOG_023,1,3,95,200, ("This key doesn't fit!\
Maybe it's for\
another door!"))

smlua_text_utils_dialog_replace(DIALOG_024,1,5,95,200, ("24"))

smlua_text_utils_dialog_replace(DIALOG_025,1,4,95,200, ("It takes the power of\
3 Stars to open this\
door. You need [%] more\
Stars."))

smlua_text_utils_dialog_replace(DIALOG_026,1,4,95,200, ("It takes the power of\
8 Stars to open this\
door. You need [%] more\
Stars."))

smlua_text_utils_dialog_replace(DIALOG_027,1,4,95,200, ("It takes the power of\
30 Stars to open this\
door. You need [%] more\
Stars."))

smlua_text_utils_dialog_replace(DIALOG_028,1,4,95,200, ("It takes the power of\
50 Stars to open this\
door. You need [%] more\
Stars."))

smlua_text_utils_dialog_replace(DIALOG_029,1,5,95,200, ("29"))

smlua_text_utils_dialog_replace(DIALOG_030,1,6,30,200, ("30"))

smlua_text_utils_dialog_replace(DIALOG_031,1,5,30,200, ("Guess you are still\
as good as back then.\
Here take this star,\
I will enjoy the cold\
water here for now."))

smlua_text_utils_dialog_replace(DIALOG_032,1,5,30,200, ("32"))

smlua_text_utils_dialog_replace(DIALOG_033,1,5,30,200, ("You found your way to\
the Peaceful Plains.\
This small valley has\
1 star for you to\
collect! Go find it."))

smlua_text_utils_dialog_replace(DIALOG_034,1,6,30,200, ("34"))

smlua_text_utils_dialog_replace(DIALOG_035,1,5,30,200, ("35"))

smlua_text_utils_dialog_replace(DIALOG_036,1,5,30,200, ("36"))

smlua_text_utils_dialog_replace(DIALOG_037,1,2,30,200, ("37"))

smlua_text_utils_dialog_replace(DIALOG_038,1,3,95,200, ("R.I.P star,\
never forget O:"))

smlua_text_utils_dialog_replace(DIALOG_039,1,4,30,200, ("39"))

smlua_text_utils_dialog_replace(DIALOG_040,1,7,30,200, ("Hey you! Need a hint\
for the caps?\
Well I tell you how\
the levels look like\
in which they are in!\
\
\
One is in a level\
with mushrooms.\
One is in a really\
red level in the\
darkness of it.\
One is in a very\
sandy level."))

smlua_text_utils_dialog_replace(DIALOG_041,1,3,30,200, ("Better luck next\
time you scrub!"))

smlua_text_utils_dialog_replace(DIALOG_042,1,4,30,200, ("If you ever find a\
picture of a tower,\
try jumping into it."))

smlua_text_utils_dialog_replace(DIALOG_043,1,5,30,200, ("43"))

smlua_text_utils_dialog_replace(DIALOG_044,1,5,95,200, ("44"))

smlua_text_utils_dialog_replace(DIALOG_045,1,6,95,200, ("45"))

smlua_text_utils_dialog_replace(DIALOG_046,1,5,30,200, ("46"))

smlua_text_utils_dialog_replace(DIALOG_047,1,2,95,200, ("Hi! I'll prepare the\
cannon for you!"))

smlua_text_utils_dialog_replace(DIALOG_048,1,4,30,200, ("48"))

smlua_text_utils_dialog_replace(DIALOG_049,1,4,30,200, ("How to get into that\
cage? Well, there isn't\
a vanish cap around\
to help you, but I\
heard that in the town\
some flowers can bring\
you there, if you stand\
still in them."))

smlua_text_utils_dialog_replace(DIALOG_050,1,2,30,200, ("Welcome to Folly Bay\
Town! Enjoy your stay."))

smlua_text_utils_dialog_replace(DIALOG_051,1,4,30,200, ("You want to get up the\
buildings? Somewhere\
in the back should be\
a way up."))

smlua_text_utils_dialog_replace(DIALOG_052,1,3,30,200, ("I come here to be alone,\
mind if you could go\
away again?"))

smlua_text_utils_dialog_replace(DIALOG_053,1,5,30,200, ("Something tells me\
that a vanish cap\
should be here... maybe\
you need more stars\
for it to show up."))

smlua_text_utils_dialog_replace(DIALOG_054,1,5,30,200, ("54"))

smlua_text_utils_dialog_replace(DIALOG_055,1,4,30,200, ("55\
Ready...\
\
//Go//// Don't Go"))

smlua_text_utils_dialog_replace(DIALOG_056,1,6,30,200, ("56"))

smlua_text_utils_dialog_replace(DIALOG_057,1,4,30,200, ("SHOOOOOoooooooot!\
\
MARIO! Have you seen\
my child somewhere?\
\
That lil sh★t ran\
away again and I\
need to punish her\
for that! Get her\
back to me and you\
can have a star!"))

smlua_text_utils_dialog_replace(DIALOG_058,1,4,30,200, ("You found my precious,\
precious baby! How\
are you? Are you\
ok? Oh Mario how can\
I thank you?\
Here take this star!"))

smlua_text_utils_dialog_replace(DIALOG_059,1,4,30,200, ("That's not my baby!\
Remove that thing\
from my view, burn\
it or do whatever you\
want with that, but\
don't give it to me!"))

smlua_text_utils_dialog_replace(DIALOG_060,1,4,30,200, ("60"))

smlua_text_utils_dialog_replace(DIALOG_061,1,4,30,200, ("61"))

smlua_text_utils_dialog_replace(DIALOG_062,1,3,30,200, ("62"))

smlua_text_utils_dialog_replace(DIALOG_063,1,5,30,200, ("63"))

smlua_text_utils_dialog_replace(DIALOG_064,1,5,30,200, ("64"))

smlua_text_utils_dialog_replace(DIALOG_065,1,6,30,200, ("65"))

smlua_text_utils_dialog_replace(DIALOG_066,1,5,30,200, ("66\
fate is in your hands."))

smlua_text_utils_dialog_replace(DIALOG_067,1,5,30,200, ("Mario... is that you?\
Those stars are\
controlling me! But\
other than that, this\
is MY key! You won't\
get it from me!"))

smlua_text_utils_dialog_replace(DIALOG_068,1,5,30,200, ("68"))

smlua_text_utils_dialog_replace(DIALOG_069,1,6,30,200, ("Star Revenge (1.5) -\
Star Takeover Redone\
Version 2.2\
Hack made by BroDute\
Original Game by\
Nintendo.\
Levels - BroDute\
Music - The cool\
guys from SMWCentral\
Textures:\
Enemys - BroDute\
HUD - BroDute\
Leveltextures -\
BroDute and\
SMWCentral\
Tools - Frauber,\
VL-Tune, Trashlux"))

smlua_text_utils_dialog_replace(DIALOG_070,1,5,30,200, ("      - Danger -\
\
In the area below you\
has toxic gas. Make sure\
you have the metal\
cap switch pressed\
before going in. Also\
switch to Lakitu cam,\
since Mario cam is \
an idiot in this gas."))

smlua_text_utils_dialog_replace(DIALOG_071,1,3,30,200, ("Cap stage ahead!\
\
You will loose your\
coins, secrets etc. when\
you enter this pipe.\
\
There will be 3 star\
in here to find."))

smlua_text_utils_dialog_replace(DIALOG_072,1,5,30,200, ("Sorry, I went up to the\
top of this lava fall to\
get a better view, come\
see me if you want to\
use the cannon."))

smlua_text_utils_dialog_replace(DIALOG_073,1,1,95,200, ("Hey, how are you doing?"))

smlua_text_utils_dialog_replace(DIALOG_074,1,5,30,200, ("---"))

smlua_text_utils_dialog_replace(DIALOG_075,1,5,30,200, ("75"))

smlua_text_utils_dialog_replace(DIALOG_076,1,6,30,200, ("76"))

smlua_text_utils_dialog_replace(DIALOG_077,1,6,150,200, ("- Snow Mountain Slide -\
This small slide has\
4 stars.\
One of them\
will be for beating\
the slide under 14『0 "))

smlua_text_utils_dialog_replace(DIALOG_078,1,5,30,200, ("This statue here was\
made for our first\
big bully who found\
this cave and made it\
our home base.\
Many generations past,\
this cave still is a\
home to many bullies.\
\
Somehow most of them,\
who live here get\
really jealous about\
eveything when they\
came to close to the\
room at the top right.\
\
Because to such things\
and other problems,\
we are low on money\
here in the caverns."))

smlua_text_utils_dialog_replace(DIALOG_079,1,4,30,200, ("79"))

smlua_text_utils_dialog_replace(DIALOG_080,1,1,30,200, ("80"))

smlua_text_utils_dialog_replace(DIALOG_081,1,4,30,200, ("This here was a temple\
to keep the triforce\
safe, yet it wasn't\
safe here. There are\
still 3 stars left in\
here, may you find\
them. Also watch\
out, the walls have\
eyes here..."))

smlua_text_utils_dialog_replace(DIALOG_082,1,4,30,200, ("dkglmfddmkldJdfggdgd\
dgldgmegsUdksnkankfs\
epqlcnjkrwkjreMrrekr\
wpovsPdkshnrlksnjakj"))

smlua_text_utils_dialog_replace(DIALOG_083,1,6,30,200, ("You got up here to\
me? I was guessing\
that I would be save\
from you up here.\
Here, take this star!"))

smlua_text_utils_dialog_replace(DIALOG_084,1,3,30,200, ("Oh boy, it's Mario!\
What makes you come\
all the way up here?\
A star? Yeah I have\
one. Take it and\
get out of my eyes,\
I want to enjoy the\
sunset that will never\
end for some reason."))

smlua_text_utils_dialog_replace(DIALOG_085,1,5,30,200, ("85"))

smlua_text_utils_dialog_replace(DIALOG_086,1,3,30,200, ("86"))

smlua_text_utils_dialog_replace(DIALOG_087,1,4,30,200, ("87"))

smlua_text_utils_dialog_replace(DIALOG_088,1,5,30,200, ("88"))

smlua_text_utils_dialog_replace(DIALOG_089,1,5,95,200, ("89"))

smlua_text_utils_dialog_replace(DIALOG_090,1,6,30,200, ("90"))

smlua_text_utils_dialog_replace(DIALOG_091,2,2,30,200, ("91"))

smlua_text_utils_dialog_replace(DIALOG_092,1,5,30,200, ("HEY YOU! Get out of\
our land! This is\
the state of the\
blue stars now! We\
have Peach and Bowser!\
\
Go away now or face\
the you greatest\
fear! Go get him\
Baka Rock!"))

smlua_text_utils_dialog_replace(DIALOG_093,1,5,30,200, ("Mario! You again!\
Can you now finally\
save me from this\
curse? I can't take\
this stars anymore...\
\
SHUT UP! MARIO!\
Give us back the stars\
you stole from us\
and admit defeat\
already! You can't\
stop us, we are\
invincible!!!"))

smlua_text_utils_dialog_replace(DIALOG_094,1,4,30,200, ("94"))

smlua_text_utils_dialog_replace(DIALOG_095,1,4,30,200, ("95"))

smlua_text_utils_dialog_replace(DIALOG_096,1,4,30,200, ("96"))

smlua_text_utils_dialog_replace(DIALOG_097,1,5,30,200, ("97"))

smlua_text_utils_dialog_replace(DIALOG_098,1,2,95,200, ("98"))

smlua_text_utils_dialog_replace(DIALOG_099,1,5,95,200, ("99"))

smlua_text_utils_dialog_replace(DIALOG_100,1,3,95,200, ("100"))

smlua_text_utils_dialog_replace(DIALOG_101,1,3,95,200, ("101"))

smlua_text_utils_dialog_replace(DIALOG_102,1,5,30,200, ("102"))

smlua_text_utils_dialog_replace(DIALOG_103,1,4,95,200, ("103"))

smlua_text_utils_dialog_replace(DIALOG_104,1,5,30,200, ("104"))

smlua_text_utils_dialog_replace(DIALOG_105,1,3,95,200, ("Ready for blastoff! Come\
on, hop into the cannon!\
\
You can reach the Star on\
the floating island by\
using the four cannons.\
Use the Control Stick to\
aim, then press [A] to fire.\
\
If you're handy, you can\
grab on to trees or poles\
to land."))

smlua_text_utils_dialog_replace(DIALOG_106,1,2,95,200, ("Ready for blastoff! Come\
on, hop into the cannon!"))

smlua_text_utils_dialog_replace(DIALOG_107,1,3,95,200, ("107"))

smlua_text_utils_dialog_replace(DIALOG_108,1,2,95,200, ("108"))

smlua_text_utils_dialog_replace(DIALOG_109,1,4,95,200, ("109"))

smlua_text_utils_dialog_replace(DIALOG_110,1,5,95,200, ("110"))

smlua_text_utils_dialog_replace(DIALOG_111,1,4,95,200, ("111"))

smlua_text_utils_dialog_replace(DIALOG_112,1,4,30,200, ("112"))

smlua_text_utils_dialog_replace(DIALOG_113,1,6,30,200, ("113"))

smlua_text_utils_dialog_replace(DIALOG_114,1,5,95,200, ("I may be small but\
you won't get my star!\
\
It's mine, I found it\
first! Now let me\
crush you under me!"))

smlua_text_utils_dialog_replace(DIALOG_115,1,5,95,200, ("No! My star... It\
took me long to...\
wait, how did I even\
end up here? Errrr...."))

smlua_text_utils_dialog_replace(DIALOG_116,1,5,95,200, ("Guess I lost the\
battle! I'm going to\
buy me some sand and\
build some sand forts.\
Maybe we will see\
again, but for now\
take this star here!"))

smlua_text_utils_dialog_replace(DIALOG_117,1,1,95,200, ("Bakarock to compete!"))

smlua_text_utils_dialog_replace(DIALOG_118,1,6,95,200, ("Ice Hand Entei? FALLED"))

smlua_text_utils_dialog_replace(DIALOG_119,1,6,30,200, ("Well I said you should\
help me and not try\
to KILL ME! Take this\
key, I go into the\
Star Tower for now!\
\
And next time help\
me and not destroy me!"))

smlua_text_utils_dialog_replace(DIALOG_120,1,4,30,200, ("120"))

smlua_text_utils_dialog_replace(DIALOG_121,1,5,30,200, ("Finally free from\
this curse! Take\
this big star to\
save Peach! I'm gonna\
take a break now and\
look around this place\
in hope to have some\
hollidays here.\
\
Btw, the credits will\
just break on course\
3, so don't be\
surprised when it\
happends!"))

smlua_text_utils_dialog_replace(DIALOG_122,1,4,30,200, ("122"))

smlua_text_utils_dialog_replace(DIALOG_123,1,4,30,200, ("123"))

smlua_text_utils_dialog_replace(DIALOG_124,1,4,30,200, ("124"))

smlua_text_utils_dialog_replace(DIALOG_125,1,3,30,200, ("125"))

smlua_text_utils_dialog_replace(DIALOG_126,2,3,30,200, ("126"))

smlua_text_utils_dialog_replace(DIALOG_127,3,4,30,200, ("127"))

smlua_text_utils_dialog_replace(DIALOG_128,1,4,95,200, ("You must fight with\
honor! It is against the\
royal rules to throw the\
prince out of the ring!"))

smlua_text_utils_dialog_replace(DIALOG_129,1,5,30,200, ("129"))

smlua_text_utils_dialog_replace(DIALOG_130,1,5,30,200, ("130"))

smlua_text_utils_dialog_replace(DIALOG_131,1,5,30,200, ("131"))

smlua_text_utils_dialog_replace(DIALOG_132,1,4,30,200, ("Whoa, Mario, pal, you\
aren't trying to cheat,\
are you? Shortcuts aren't\
allowed."))

smlua_text_utils_dialog_replace(DIALOG_133,1,6,30,200, ("There isn't any new\
star here, just go and\
regrab this one on\
the middle.\
You can keep the 1-ups\
tho if you like."))

smlua_text_utils_dialog_replace(DIALOG_134,1,5,30,200, ("134"))

smlua_text_utils_dialog_replace(DIALOG_135,1,5,30,200, ("135"))

smlua_text_utils_dialog_replace(DIALOG_136,1,6,30,200, ("136"))

smlua_text_utils_dialog_replace(DIALOG_137,1,6,30,200, ("137"))

smlua_text_utils_dialog_replace(DIALOG_138,1,3,30,200, ("138"))

smlua_text_utils_dialog_replace(DIALOG_139,1,6,30,200, ("139"))

smlua_text_utils_dialog_replace(DIALOG_140,1,6,30,200, ("140"))

smlua_text_utils_dialog_replace(DIALOG_141,1,5,150,200, ("You have 1 star now!"))

smlua_text_utils_dialog_replace(DIALOG_142,1,5,150,200, ("You have 3 stars now!"))

smlua_text_utils_dialog_replace(DIALOG_143,1,6,150,200, ("You have 8 stars now!"))

smlua_text_utils_dialog_replace(DIALOG_144,1,6,150,200, ("You have 30 stars now!"))

smlua_text_utils_dialog_replace(DIALOG_145,1,6,150,200, ("You have 50 stars now!"))

smlua_text_utils_dialog_replace(DIALOG_146,1,6,150,200, ("You have 70 stars now!"))

smlua_text_utils_dialog_replace(DIALOG_147,1,8,30,200, ("BEWARE! You are now\
in the center of\
the power of the\
blue stars! Because of\
this power you will\
move twice as fast!\
You may see a 2nd\
yourself sometimes!\
Anyway, there are 5\
stars in here. The first\
4 of them will want\
you to collect 25\
red coins. Just\
go into the pipe\
and start the 『fun『.\
\
On star 5 you will move\
even faster and have\
acces to all areas, but\
they will be only 2\
red coins per area!"))

smlua_text_utils_dialog_replace(DIALOG_148,1,6,30,200, ("148"))

smlua_text_utils_dialog_replace(DIALOG_149,1,3,30,200, ("149"))

smlua_text_utils_dialog_replace(DIALOG_150,1,5,30,200, ("150"))

smlua_text_utils_dialog_replace(DIALOG_151,1,4,30,200, ("151"))

smlua_text_utils_dialog_replace(DIALOG_152,1,3,30,200, ("152"))

smlua_text_utils_dialog_replace(DIALOG_153,1,4,30,200, ("153"))

smlua_text_utils_dialog_replace(DIALOG_154,1,5,30,200, ("154"))

smlua_text_utils_dialog_replace(DIALOG_155,1,6,30,200, ("155"))

smlua_text_utils_dialog_replace(DIALOG_156,1,5,30,200, ("What do you want?\
There is a rabbit\
on the 2nd overworld\
that has 2 star...\
more I don't know!"))

smlua_text_utils_dialog_replace(DIALOG_157,1,5,30,200, ("157"))

smlua_text_utils_dialog_replace(DIALOG_158,1,6,30,200, ("Warning, if you enter\
this temple without\
breaking the seal,\
you will end up in\
an broken world with\
all 7 stars just\
randomly sitting in\
places were they\
shoudn't be at."))

smlua_text_utils_dialog_replace(DIALOG_159,1,6,30,200, ("Bowser here:\
Yo Mario, I found a\
little free time from\
the whole hypnosis\
thingy so I wrote this\
sign here to help.\
So all you got to do is\
using one of the four\
warps to find a star.\
After you collect one\
you will be send to\
my pipe.\
If you somehow got all\
stars can use the door\
on the side here to just\
skip having to get a star.\
\
\
Speaking of stars, when\
these stars first attacked\
they seem to have\
entered from the blue\
section... maybe you\
want to check that."))

smlua_text_utils_dialog_replace(DIALOG_160,1,1,30,200, ("Sorry, I'm not home..."))

smlua_text_utils_dialog_replace(DIALOG_161,1,4,30,200, ("161"))

smlua_text_utils_dialog_replace(DIALOG_162,1,4,30,200, ("Go away! I don't want\
to hang out with you!\
Take this 2nd star and\
let me have my peace!"))

smlua_text_utils_dialog_replace(DIALOG_163,1,5,30,200, ("Finally free from\
this curse! Take\
this big star to\
save Peach! I'm gonna\
take a break now and\
look around this place\
in hope to have some\
hollidays here.\
\
Oh, you got more\
than 119 stars?\
Guess you liked the\
hack so much that\
you got all the\
stars? Anyway I'm\
done for now, cya\
in the next game!\
\
Btw, the credits will\
just break on course\
3, so don't be\
surprised when it\
happends!"))

smlua_text_utils_dialog_replace(DIALOG_164,1,4,30,200, ("164\
//Go//// Don't Go"))

smlua_text_utils_dialog_replace(DIALOG_165,1,6,30,200, ("If you ever find a very\
hidden vanish cap box\
around here, then\
NEVER start a race\
while having it on,\
the game won't like it!"))

smlua_text_utils_dialog_replace(DIALOG_166,1,3,30,200, ("Don't question the\
place you have just\
arrived in, just accept."))

smlua_text_utils_dialog_replace(DIALOG_167,1,4,30,200, ("To the temple of\
the soulless stars.\
\
Blocked since 1981."))

smlua_text_utils_dialog_replace(DIALOG_168,1,5,30,200, ("168"))

smlua_text_utils_dialog_replace(DIALOG_169,1,1,30,200, ("Avoid the purple ink!"))

