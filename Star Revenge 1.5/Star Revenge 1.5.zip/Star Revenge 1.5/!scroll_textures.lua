add_scroll_target(0, "VB_bbh_1_0xe02c320", 0, 13)
add_scroll_target(0, "VB_bbh_1_0xe02c3f0", 0, 15)
-- Count: 28

add_scroll_target(1, "VB_bbh_1_0xe06d670", 0, 15)
add_scroll_target(1, "VB_bbh_1_0xe06d760", 0, 13)
add_scroll_target(1, "VB_bbh_1_0xe06d830", 0, 11)
-- Count: 39

add_scroll_target(2, "VB_hmc_1_0xe02f8c0", 0, 4)
-- Count: 4

add_scroll_target(3, "VB_hmc_1_0xe033440", 0, 13)
add_scroll_target(3, "VB_hmc_1_0xe033510", 0, 14)
add_scroll_target(3, "VB_hmc_1_0xe0335f0", 0, 15)
add_scroll_target(3, "VB_hmc_1_0xe0336e0", 0, 6)
-- Count: 48

add_scroll_target(4, "VB_hmc_1_0xe033740", 0, 15)
add_scroll_target(4, "VB_hmc_1_0xe033830", 0, 15)
add_scroll_target(4, "VB_hmc_1_0xe033920", 0, 15)
add_scroll_target(4, "VB_hmc_1_0xe033a10", 0, 15)
add_scroll_target(4, "VB_hmc_1_0xe033b00", 0, 15)
add_scroll_target(4, "VB_hmc_1_0xe033bf0", 0, 15)
add_scroll_target(4, "VB_hmc_1_0xe033ce0", 0, 15)
add_scroll_target(4, "VB_hmc_1_0xe033dd0", 0, 15)
add_scroll_target(4, "VB_hmc_1_0xe033ec0", 0, 8)
-- Count: 128

add_scroll_target(5, "VB_hmc_1_0xe0393f0", 0, 15)
add_scroll_target(5, "VB_hmc_1_0xe0394e0", 0, 15)
add_scroll_target(5, "VB_hmc_1_0xe0395d0", 0, 15)
add_scroll_target(5, "VB_hmc_1_0xe0396c0", 0, 14)
add_scroll_target(5, "VB_hmc_1_0xe0397a0", 0, 15)
add_scroll_target(5, "VB_hmc_1_0xe039890", 0, 15)
add_scroll_target(5, "VB_hmc_1_0xe039980", 0, 15)
add_scroll_target(5, "VB_hmc_1_0xe039a70", 0, 14)
add_scroll_target(5, "VB_hmc_1_0xe039b50", 0, 3)
-- Count: 121

add_scroll_target(6, "VB_ssl_1_0xe0239c0", 0, 15)
add_scroll_target(6, "VB_ssl_1_0xe023ab0", 0, 14)
add_scroll_target(6, "VB_ssl_1_0xe023b90", 0, 15)
add_scroll_target(6, "VB_ssl_1_0xe023c80", 0, 15)
add_scroll_target(6, "VB_ssl_1_0xe023d70", 0, 15)
add_scroll_target(6, "VB_ssl_1_0xe023e60", 0, 15)
add_scroll_target(6, "VB_ssl_1_0xe023f50", 0, 15)
add_scroll_target(6, "VB_ssl_1_0xe024040", 0, 13)
add_scroll_target(6, "VB_ssl_1_0xe024110", 0, 6)
-- Count: 123

add_scroll_target(7, "VB_ssl_1_0xe03d210", 0, 15)
add_scroll_target(7, "VB_ssl_1_0xe03d300", 0, 15)
add_scroll_target(7, "VB_ssl_1_0xe03d3f0", 0, 15)
add_scroll_target(7, "VB_ssl_1_0xe03d4e0", 0, 13)
add_scroll_target(7, "VB_ssl_1_0xe03d5b0", 0, 14)
add_scroll_target(7, "VB_ssl_1_0xe03d690", 0, 13)
add_scroll_target(7, "VB_ssl_1_0xe03d760", 0, 15)
add_scroll_target(7, "VB_ssl_1_0xe03d850", 0, 15)
add_scroll_target(7, "VB_ssl_1_0xe03d940", 0, 14)
add_scroll_target(7, "VB_ssl_1_0xe03da20", 0, 15)
add_scroll_target(7, "VB_ssl_1_0xe03db10", 0, 14)
add_scroll_target(7, "VB_ssl_1_0xe03dbf0", 0, 15)
add_scroll_target(7, "VB_ssl_1_0xe03dce0", 0, 15)
add_scroll_target(7, "VB_ssl_1_0xe03ddd0", 0, 14)
add_scroll_target(7, "VB_ssl_1_0xe03deb0", 0, 9)
-- Count: 211

add_scroll_target(8, "VB_ssl_1_0xe03df40", 0, 15)
add_scroll_target(8, "VB_ssl_1_0xe03e030", 0, 3)
-- Count: 18

add_scroll_target(9, "VB_ssl_1_0xe03e060", 0, 15)
add_scroll_target(9, "VB_ssl_1_0xe03e150", 0, 14)
add_scroll_target(9, "VB_ssl_1_0xe03e230", 0, 15)
add_scroll_target(9, "VB_ssl_1_0xe03e320", 0, 13)
add_scroll_target(9, "VB_ssl_1_0xe03e3f0", 0, 15)
add_scroll_target(9, "VB_ssl_1_0xe03e4e0", 0, 7)
-- Count: 79

add_scroll_target(10, "VB_bob_1_0xe02cb30", 0, 15)
add_scroll_target(10, "VB_bob_1_0xe02cc20", 0, 12)
-- Count: 27

add_scroll_target(11, "VB_bob_1_0xe02cce0", 0, 14)
add_scroll_target(11, "VB_bob_1_0xe02cdc0", 0, 3)
-- Count: 17

add_scroll_target(12, "VB_thi_1_0xe01c4d0", 0, 14)
add_scroll_target(12, "VB_thi_1_0xe01c5b0", 0, 14)
add_scroll_target(12, "VB_thi_1_0xe01c690", 0, 3)
-- Count: 31

add_scroll_target(13, "VB_ttc_1_0xe013440", 0, 15)
add_scroll_target(13, "VB_ttc_1_0xe013530", 0, 15)
add_scroll_target(13, "VB_ttc_1_0xe013620", 0, 12)
-- Count: 42

add_scroll_target(14, "VB_castle_grounds_1_0xe030580", 0, 15)
add_scroll_target(14, "VB_castle_grounds_1_0xe030670", 0, 14)
add_scroll_target(14, "VB_castle_grounds_1_0xe030750", 0, 12)
-- Count: 41

add_scroll_target(15, "VB_castle_grounds_1_0xe03ad10", 0, 15)
add_scroll_target(15, "VB_castle_grounds_1_0xe03ae00", 0, 15)
add_scroll_target(15, "VB_castle_grounds_1_0xe03aef0", 0, 15)
add_scroll_target(15, "VB_castle_grounds_1_0xe03afe0", 0, 4)
-- Count: 49

add_scroll_target(16, "VB_castle_grounds_1_0xe03c5a0", 0, 13)
add_scroll_target(16, "VB_castle_grounds_1_0xe03c670", 0, 14)
add_scroll_target(16, "VB_castle_grounds_1_0xe03c750", 0, 4)
-- Count: 31

add_scroll_target(17, "VB_castle_grounds_1_0xe042dc0", 0, 11)
-- Count: 11

add_scroll_target(18, "VB_bitdw_1_0xe020b60", 0, 15)
add_scroll_target(18, "VB_bitdw_1_0xe020c50", 0, 13)
add_scroll_target(18, "VB_bitdw_1_0xe020d20", 0, 15)
add_scroll_target(18, "VB_bitdw_1_0xe020e10", 0, 15)
add_scroll_target(18, "VB_bitdw_1_0xe020f00", 0, 15)
add_scroll_target(18, "VB_bitdw_1_0xe020ff0", 0, 15)
add_scroll_target(18, "VB_bitdw_1_0xe0210e0", 0, 13)
add_scroll_target(18, "VB_bitdw_1_0xe0211b0", 0, 14)
add_scroll_target(18, "VB_bitdw_1_0xe021290", 0, 15)
add_scroll_target(18, "VB_bitdw_1_0xe021380", 0, 15)
add_scroll_target(18, "VB_bitdw_1_0xe021470", 0, 14)
add_scroll_target(18, "VB_bitdw_1_0xe021550", 0, 14)
add_scroll_target(18, "VB_bitdw_1_0xe021630", 0, 14)
add_scroll_target(18, "VB_bitdw_1_0xe021710", 0, 15)
add_scroll_target(18, "VB_bitdw_1_0xe021800", 0, 15)
-- Count: 217

add_scroll_target(19, "VB_vcutm_1_0xe021e80", 0, 15)
add_scroll_target(19, "VB_vcutm_1_0xe021f70", 0, 15)
add_scroll_target(19, "VB_vcutm_1_0xe022060", 0, 15)
add_scroll_target(19, "VB_vcutm_1_0xe022150", 0, 15)
add_scroll_target(19, "VB_vcutm_1_0xe022240", 0, 14)
add_scroll_target(19, "VB_vcutm_1_0xe022320", 0, 15)
add_scroll_target(19, "VB_vcutm_1_0xe022410", 0, 15)
add_scroll_target(19, "VB_vcutm_1_0xe022500", 0, 15)
add_scroll_target(19, "VB_vcutm_1_0xe0225f0", 0, 15)
add_scroll_target(19, "VB_vcutm_1_0xe0226e0", 0, 14)
add_scroll_target(19, "VB_vcutm_1_0xe0227c0", 0, 15)
add_scroll_target(19, "VB_vcutm_1_0xe0228b0", 0, 13)
add_scroll_target(19, "VB_vcutm_1_0xe022980", 0, 15)
add_scroll_target(19, "VB_vcutm_1_0xe022a70", 0, 14)
add_scroll_target(19, "VB_vcutm_1_0xe022b50", 0, 15)
add_scroll_target(19, "VB_vcutm_1_0xe022c40", 0, 15)
add_scroll_target(19, "VB_vcutm_1_0xe022d30", 0, 15)
add_scroll_target(19, "VB_vcutm_1_0xe022e20", 0, 15)
add_scroll_target(19, "VB_vcutm_1_0xe022f10", 0, 15)
add_scroll_target(19, "VB_vcutm_1_0xe023000", 0, 15)
add_scroll_target(19, "VB_vcutm_1_0xe0230f0", 0, 15)
add_scroll_target(19, "VB_vcutm_1_0xe0231e0", 0, 15)
add_scroll_target(19, "VB_vcutm_1_0xe0232d0", 0, 15)
add_scroll_target(19, "VB_vcutm_1_0xe0233c0", 0, 15)
add_scroll_target(19, "VB_vcutm_1_0xe0234b0", 0, 15)
add_scroll_target(19, "VB_vcutm_1_0xe0235a0", 0, 15)
add_scroll_target(19, "VB_vcutm_1_0xe023690", 0, 15)
add_scroll_target(19, "VB_vcutm_1_0xe023780", 0, 15)
add_scroll_target(19, "VB_vcutm_1_0xe023870", 0, 15)
add_scroll_target(19, "VB_vcutm_1_0xe023960", 0, 15)
add_scroll_target(19, "VB_vcutm_1_0xe023a50", 0, 15)
add_scroll_target(19, "VB_vcutm_1_0xe023b40", 0, 15)
add_scroll_target(19, "VB_vcutm_1_0xe023c30", 0, 15)
add_scroll_target(19, "VB_vcutm_1_0xe023d20", 0, 15)
add_scroll_target(19, "VB_vcutm_1_0xe023e10", 0, 15)
add_scroll_target(19, "VB_vcutm_1_0xe023f00", 0, 15)
add_scroll_target(19, "VB_vcutm_1_0xe023ff0", 0, 15)
add_scroll_target(19, "VB_vcutm_1_0xe0240e0", 0, 15)
add_scroll_target(19, "VB_vcutm_1_0xe0241d0", 0, 15)
add_scroll_target(19, "VB_vcutm_1_0xe0242c0", 0, 15)
add_scroll_target(19, "VB_vcutm_1_0xe0243b0", 0, 15)
add_scroll_target(19, "VB_vcutm_1_0xe0244a0", 0, 15)
add_scroll_target(19, "VB_vcutm_1_0xe024590", 0, 15)
add_scroll_target(19, "VB_vcutm_1_0xe024680", 0, 15)
add_scroll_target(19, "VB_vcutm_1_0xe024770", 0, 15)
add_scroll_target(19, "VB_vcutm_1_0xe024860", 0, 15)
add_scroll_target(19, "VB_vcutm_1_0xe024950", 0, 15)
add_scroll_target(19, "VB_vcutm_1_0xe024a40", 0, 15)
-- Count: 715

add_scroll_target(20, "VB_bitfs_1_0xe010c20", 0, 15)
add_scroll_target(20, "VB_bitfs_1_0xe010d10", 0, 15)
add_scroll_target(20, "VB_bitfs_1_0xe010e00", 0, 10)
-- Count: 40

add_scroll_target(21, "VB_bitfs_1_0xe0123d0", 0, 15)
add_scroll_target(21, "VB_bitfs_1_0xe0124c0", 0, 14)
add_scroll_target(21, "VB_bitfs_1_0xe0125a0", 0, 15)
add_scroll_target(21, "VB_bitfs_1_0xe012690", 0, 15)
add_scroll_target(21, "VB_bitfs_1_0xe012780", 0, 14)
add_scroll_target(21, "VB_bitfs_1_0xe012860", 0, 15)
add_scroll_target(21, "VB_bitfs_1_0xe012950", 0, 15)
add_scroll_target(21, "VB_bitfs_1_0xe012a40", 0, 15)
add_scroll_target(21, "VB_bitfs_1_0xe012b30", 0, 15)
add_scroll_target(21, "VB_bitfs_1_0xe012c20", 0, 15)
add_scroll_target(21, "VB_bitfs_1_0xe012d10", 0, 13)
add_scroll_target(21, "VB_bitfs_1_0xe012de0", 0, 3)
-- Count: 164

add_scroll_target(22, "VB_sa_1_0xe0427c0", 0, 15)
add_scroll_target(22, "VB_sa_1_0xe0428b0", 0, 15)
add_scroll_target(22, "VB_sa_1_0xe0429a0", 0, 15)
add_scroll_target(22, "VB_sa_1_0xe042a90", 0, 15)
add_scroll_target(22, "VB_sa_1_0xe042b80", 0, 4)
-- Count: 64

add_scroll_target(23, "VB_sa_1_0xe045a40", 0, 15)
add_scroll_target(23, "VB_sa_1_0xe045b30", 0, 3)
-- Count: 18

add_scroll_target(24, "VB_bits_1_0xe034ed0", 0, 15)
add_scroll_target(24, "VB_bits_1_0xe034fc0", 0, 15)
add_scroll_target(24, "VB_bits_1_0xe0350b0", 0, 15)
add_scroll_target(24, "VB_bits_1_0xe0351a0", 0, 15)
add_scroll_target(24, "VB_bits_1_0xe035290", 0, 6)
-- Count: 66

add_scroll_target(25, "VB_bits_1_0xe043590", 0, 15)
add_scroll_target(25, "VB_bits_1_0xe043680", 0, 15)
add_scroll_target(25, "VB_bits_1_0xe043770", 0, 14)
add_scroll_target(25, "VB_bits_1_0xe043850", 0, 15)
add_scroll_target(25, "VB_bits_1_0xe043940", 0, 14)
add_scroll_target(25, "VB_bits_1_0xe043a20", 0, 3)
-- Count: 76

add_scroll_target(26, "VB_bits_1_0xe043a50", 0, 13)
add_scroll_target(26, "VB_bits_1_0xe043b20", 0, 15)
-- Count: 28

add_scroll_target(27, "VB_bits_1_0xe043c10", 0, 8)
-- Count: 8

add_scroll_target(28, "VB_bits_1_0xe045da0", 0, 14)
add_scroll_target(28, "VB_bits_1_0xe045e80", 0, 14)
add_scroll_target(28, "VB_bits_1_0xe045f60", 0, 14)
add_scroll_target(28, "VB_bits_1_0xe046040", 0, 15)
add_scroll_target(28, "VB_bits_1_0xe046130", 0, 14)
add_scroll_target(28, "VB_bits_1_0xe046210", 0, 15)
add_scroll_target(28, "VB_bits_1_0xe046300", 0, 15)
add_scroll_target(28, "VB_bits_1_0xe0463f0", 0, 8)
-- Count: 109

add_scroll_target(29, "VB_lll_1_0xe043d60", 0, 12)
-- Count: 12

add_scroll_target(30, "VB_lll_1_0xe044160", 0, 12)
-- Count: 12

add_scroll_target(31, "VB_lll_1_0xe044220", 0, 14)
add_scroll_target(31, "VB_lll_1_0xe044300", 0, 14)
add_scroll_target(31, "VB_lll_1_0xe0443e0", 0, 15)
add_scroll_target(31, "VB_lll_1_0xe0444d0", 0, 3)
-- Count: 46

add_scroll_target(32, "VB_ddd_1_0xe011010", 0, 15)
add_scroll_target(32, "VB_ddd_1_0xe011100", 0, 15)
add_scroll_target(32, "VB_ddd_1_0xe0111f0", 0, 14)
add_scroll_target(32, "VB_ddd_1_0xe0112d0", 0, 15)
add_scroll_target(32, "VB_ddd_1_0xe0113c0", 0, 15)
add_scroll_target(32, "VB_ddd_1_0xe0114b0", 0, 15)
add_scroll_target(32, "VB_ddd_1_0xe0115a0", 0, 15)
add_scroll_target(32, "VB_ddd_1_0xe011690", 0, 15)
add_scroll_target(32, "VB_ddd_1_0xe011780", 0, 15)
add_scroll_target(32, "VB_ddd_1_0xe011870", 0, 15)
add_scroll_target(32, "VB_ddd_1_0xe011960", 0, 15)
add_scroll_target(32, "VB_ddd_1_0xe011a50", 0, 15)
add_scroll_target(32, "VB_ddd_1_0xe011b40", 0, 15)
add_scroll_target(32, "VB_ddd_1_0xe011c30", 0, 15)
add_scroll_target(32, "VB_ddd_1_0xe011d20", 0, 14)
add_scroll_target(32, "VB_ddd_1_0xe011e00", 0, 15)
add_scroll_target(32, "VB_ddd_1_0xe011ef0", 0, 15)
add_scroll_target(32, "VB_ddd_1_0xe011fe0", 0, 15)
add_scroll_target(32, "VB_ddd_1_0xe0120d0", 0, 14)
add_scroll_target(32, "VB_ddd_1_0xe0121b0", 0, 12)
-- Count: 294

add_scroll_target(33, "VB_ddd_1_0xe05eb60", 0, 15)
add_scroll_target(33, "VB_ddd_1_0xe05ec50", 0, 15)
add_scroll_target(33, "VB_ddd_1_0xe05ed40", 0, 15)
add_scroll_target(33, "VB_ddd_1_0xe05ee30", 0, 15)
add_scroll_target(33, "VB_ddd_1_0xe05ef20", 0, 15)
add_scroll_target(33, "VB_ddd_1_0xe05f010", 0, 15)
add_scroll_target(33, "VB_ddd_1_0xe05f100", 0, 15)
add_scroll_target(33, "VB_ddd_1_0xe05f1f0", 0, 15)
add_scroll_target(33, "VB_ddd_1_0xe05f2e0", 0, 15)
add_scroll_target(33, "VB_ddd_1_0xe05f3d0", 0, 15)
add_scroll_target(33, "VB_ddd_1_0xe05f4c0", 0, 15)
add_scroll_target(33, "VB_ddd_1_0xe05f5b0", 0, 15)
add_scroll_target(33, "VB_ddd_1_0xe05f6a0", 0, 14)
add_scroll_target(33, "VB_ddd_1_0xe05f780", 0, 15)
add_scroll_target(33, "VB_ddd_1_0xe05f870", 0, 15)
add_scroll_target(33, "VB_ddd_1_0xe05f960", 0, 15)
add_scroll_target(33, "VB_ddd_1_0xe05fa50", 0, 15)
add_scroll_target(33, "VB_ddd_1_0xe05fb40", 0, 15)
add_scroll_target(33, "VB_ddd_1_0xe05fc30", 0, 15)
add_scroll_target(33, "VB_ddd_1_0xe05fd20", 0, 15)
add_scroll_target(33, "VB_ddd_1_0xe05fe10", 0, 15)
add_scroll_target(33, "VB_ddd_1_0xe05ff00", 0, 15)
add_scroll_target(33, "VB_ddd_1_0xe05fff0", 0, 15)
add_scroll_target(33, "VB_ddd_1_0xe0600e0", 0, 14)
add_scroll_target(33, "VB_ddd_1_0xe0601c0", 0, 15)
add_scroll_target(33, "VB_ddd_1_0xe0602b0", 0, 13)
add_scroll_target(33, "VB_ddd_1_0xe060380", 0, 13)
add_scroll_target(33, "VB_ddd_1_0xe060450", 0, 15)
add_scroll_target(33, "VB_ddd_1_0xe060540", 0, 14)
add_scroll_target(33, "VB_ddd_1_0xe060620", 0, 15)
add_scroll_target(33, "VB_ddd_1_0xe060710", 0, 15)
add_scroll_target(33, "VB_ddd_1_0xe060800", 0, 15)
add_scroll_target(33, "VB_ddd_1_0xe0608f0", 0, 15)
add_scroll_target(33, "VB_ddd_1_0xe0609e0", 0, 15)
add_scroll_target(33, "VB_ddd_1_0xe060ad0", 0, 15)
add_scroll_target(33, "VB_ddd_1_0xe060bc0", 0, 13)
add_scroll_target(33, "VB_ddd_1_0xe060c90", 0, 15)
add_scroll_target(33, "VB_ddd_1_0xe060d80", 0, 14)
add_scroll_target(33, "VB_ddd_1_0xe060e60", 0, 15)
add_scroll_target(33, "VB_ddd_1_0xe060f50", 0, 15)
add_scroll_target(33, "VB_ddd_1_0xe061040", 0, 15)
add_scroll_target(33, "VB_ddd_1_0xe061130", 0, 15)
add_scroll_target(33, "VB_ddd_1_0xe061220", 0, 14)
add_scroll_target(33, "VB_ddd_1_0xe061300", 0, 13)
add_scroll_target(33, "VB_ddd_1_0xe0613d0", 0, 15)
add_scroll_target(33, "VB_ddd_1_0xe0614c0", 0, 15)
add_scroll_target(33, "VB_ddd_1_0xe0615b0", 0, 13)
add_scroll_target(33, "VB_ddd_1_0xe061680", 0, 13)
add_scroll_target(33, "VB_ddd_1_0xe061750", 0, 9)
-- Count: 712

add_scroll_target(34, "VB_ddd_1_0xe0617e0", 0, 13)
add_scroll_target(34, "VB_ddd_1_0xe0618b0", 0, 13)
add_scroll_target(34, "VB_ddd_1_0xe061980", 0, 15)
add_scroll_target(34, "VB_ddd_1_0xe061a70", 0, 15)
add_scroll_target(34, "VB_ddd_1_0xe061b60", 0, 15)
add_scroll_target(34, "VB_ddd_1_0xe061c50", 0, 12)
-- Count: 83

add_scroll_target(35, "VB_wf_1_0xe0232f0", 0, 4)
-- Count: 4

add_scroll_target(36, "VB_wf_1_0xe0392f0", 0, 15)
add_scroll_target(36, "VB_wf_1_0xe0393e0", 0, 3)
-- Count: 18

add_scroll_target(37, "VB_ending_1_0xe01b2a0", 0, 15)
add_scroll_target(37, "VB_ending_1_0xe01b390", 0, 7)
-- Count: 22

add_scroll_target(38, "VB_castle_courtyard_1_0xe0435b0", 0, 4)
-- Count: 4

add_scroll_target(39, "VB_pss_1_0xe021420", 0, 15)
add_scroll_target(39, "VB_pss_1_0xe021510", 0, 13)
add_scroll_target(39, "VB_pss_1_0xe0215e0", 0, 11)
-- Count: 39

add_scroll_target(40, "VB_totwc_1_0xe0268e0", 0, 15)
add_scroll_target(40, "VB_totwc_1_0xe0269d0", 0, 15)
add_scroll_target(40, "VB_totwc_1_0xe026ac0", 0, 15)
add_scroll_target(40, "VB_totwc_1_0xe026bb0", 0, 13)
add_scroll_target(40, "VB_totwc_1_0xe026c80", 0, 15)
add_scroll_target(40, "VB_totwc_1_0xe026d70", 0, 15)
add_scroll_target(40, "VB_totwc_1_0xe026e60", 0, 14)
add_scroll_target(40, "VB_totwc_1_0xe026f40", 0, 15)
add_scroll_target(40, "VB_totwc_1_0xe027030", 0, 15)
add_scroll_target(40, "VB_totwc_1_0xe027120", 0, 15)
add_scroll_target(40, "VB_totwc_1_0xe027210", 0, 6)
-- Count: 153

add_scroll_target(41, "VB_totwc_1_0xe0361c0", 0, 8)
-- Count: 8

add_scroll_target(42, "VB_bowser_2_1_0xe006810", 0, 15)
add_scroll_target(42, "VB_bowser_2_1_0xe006900", 0, 15)
add_scroll_target(42, "VB_bowser_2_1_0xe0069f0", 0, 15)
add_scroll_target(42, "VB_bowser_2_1_0xe006ae0", 0, 15)
add_scroll_target(42, "VB_bowser_2_1_0xe006bd0", 0, 15)
add_scroll_target(42, "VB_bowser_2_1_0xe006cc0", 0, 11)
-- Count: 86

add_scroll_target(43, "VB_bowser_2_1_0xe00e510", 0, 15)
add_scroll_target(43, "VB_bowser_2_1_0xe00e600", 0, 13)
add_scroll_target(43, "VB_bowser_2_1_0xe00e6d0", 0, 11)
-- Count: 39

add_scroll_target(44, "VB_ttm_1_0xe02b5f0", 0, 15)
add_scroll_target(44, "VB_ttm_1_0xe02b6e0", 0, 15)
add_scroll_target(44, "VB_ttm_1_0xe02b7d0", 0, 13)
add_scroll_target(44, "VB_ttm_1_0xe02b8a0", 0, 13)
add_scroll_target(44, "VB_ttm_1_0xe02b970", 0, 15)
add_scroll_target(44, "VB_ttm_1_0xe02ba60", 0, 13)
add_scroll_target(44, "VB_ttm_1_0xe02bb30", 0, 9)
-- Count: 93

