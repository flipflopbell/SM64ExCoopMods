smlua_text_utils_course_acts_replace(COURSE_BOB, (" 1 FOREST LAKE VALLEY"),	("BATTLE WITH PRINCE BOB-OMB"),	("STAR OF THE PILLARS"),	("SMALL WALLJUMP PRACTICE"),	("THE CHUCKYA'S TREASURE"),	("COINS OF THE VALLEY"),	("STEP ON THE DROWNED SWITCH -MC-"))

smlua_text_utils_course_acts_replace(COURSE_WF, (" 2 MUSHROOM MOUNTAINS"),	("PATH OF THE BLACK SHROOM"),	("BETWEEN THE CANNONS"),	("OVER THE WINDY BRIDGE"),	("SECRET OF THE HOUSELESS MOUNTAIN"),	("COINS OF THE MUSHROOMS"),	("YOU KNOW THE DEAL"))

smlua_text_utils_course_acts_replace(COURSE_JRB, (" 3 FOLLY BAY TOWN"),	("LONE BLUE TOWER"),	("REDS OF THE PINK PILLARS"),	("PATH TO THE GREEN LIGHTHOUSE"),	("ALONG THE CLIFFSIDE"),	("STAR ATOP THE TOWN"),	("SECRET OF THE TOWN'S FLOWERS"))

smlua_text_utils_course_acts_replace(COURSE_CCM, (" 4 SNOW MOUNTAIN RESORT"),	("TUXIE, WHERE ARE YOU?"),	("BEHIND THE CENTRAL TUNNEL"),	("TO THE FROZEN WATERFALL"),	("PILLARS IN THE CAVE"),	("THE HIDDEN UNDERGROUND SLIDE"),	("COINS OF THE RESORT"))

smlua_text_utils_course_acts_replace(COURSE_BBH, (" 5 SKYOVER KINGDOM"),	("THE CASTLE IN THE SKY"),	("TOP OF THE LOL FORMATION"),	("NARROW PATH OF THE ENDLESS CLOUDS"),	("THE ROYAL SECRET HIDEOUT"),	("NOW THERE IS A SWITCH!"),	("COINS OF THE SKY LAND"))

smlua_text_utils_course_acts_replace(COURSE_HMC, (" 6 BLAZING BULLY CAVERN"),	("PARLLY - BIG JEALOUS BULLY"),	("BURNING BUTT MEANS STAR"),	("SURFING ON THE MAGMA"),	("DON'T FEAR THE DARKNESS"),	("METAL IN THE BLUE ZONE -MC-"),	("HIGH ABOVE THE START -WC-"))

smlua_text_utils_course_acts_replace(COURSE_LLL, (" 7 AUTUMN PLAINS"),	("TREES OF THE POISON LAKE"),	("BOX SWITCH OF THE FLOWERS"),	("INSIDE THE HIDDEN CAVE"),	("THE ARROW KNOWS"),	("METAL UP THAT SWITCH -MC-"),	("VANISH RUN TO THE ROOF -VC-"))

smlua_text_utils_course_acts_replace(COURSE_SSL, (" 8 OCHER SAND DUNES"),	("NARROW PASSAGE IN THE CANYON"),	("MINI STARS OF THE HOT LAND"),	("KOOPA'S SANDY RACE"),	("THE SLIPPERY PYRAMIDS"),	("THE FORGOTTEN CAGE"),	("FIND THE HIDDEN TRIFORCE -VC-WC-"))

smlua_text_utils_course_acts_replace(COURSE_DDD, (" 9 ORIENTAL VOLCANIC SKIES"),	("OVER THE BROKEN BRIDGE"),	("PATH OF THE VOLCANO"),	("STAR OF THE BURNING CASTLE"),	("NARROW PATH OF MT. KASAI"),	("COINS OF THE LAVA PIT -MC-"),	("FLYING IN THE SUNSET -WC-"))

smlua_text_utils_course_acts_replace(COURSE_SL, ("10 CEPHALOPOD CITY"),	("CONSTRUCTION IN THE WATER"),	("CENTER OF THE CITY"),	("SIDETRCKED OVER THE BRIDGES"),	("BOXES TO THE CLOSED OFF PART"),	("FIND THE GATE SWITCH"),	("GOT NO BLUE MONEY, BUT A HIDDEN BOX"))

smlua_text_utils_course_acts_replace(COURSE_WDW, ("11 STRANGE LETTER SPACE"),	("GET ON THE D!"),	("OHHHHHH THERE?"),	("THE Q IS, TO BE THE CLOSEST TO THE MOON"),	("MHHHHHHH... COULD BE HERE"),	("ARE YOU K THERE STAR?"),	("GET ALL DEM DANK COINS M8!"))

smlua_text_utils_course_acts_replace(COURSE_TTM, ("12 RAINBOW CROSSING GALAXY"),	("AN AGGRESSIVE BIG STAR"),	("CAVE OF THE SNOWY MOUNTAIN -MC-"),	("2 CANNONS FOR A MINI STAR"),	("BOX MAYHEM ON THE PATH TO THE TOP -VC-"),	("COINS OF THE RAINBOWS -VC-"),	("WHEN THE START IS ACTUALLY THE END -WC-"))

smlua_text_utils_course_acts_replace(COURSE_THI, ("13 DISTORTED BLUE VALLEY"),	("PIT THE OF STAR"),	("PLATFORM PRINCE'S THE "),	("WALLJUMPS ALL DEM"),	("TERRITORY HIGH IN PATH SMALL"),	("PILLARS THE OF STAR"),	("SIDE MOUNTAIN'S THE OF CAGE"))

smlua_text_utils_course_acts_replace(COURSE_TTC, ("14 SMB 1-1"),	("COINS OF THE OLD TIMES"),	("-"),	("-"),	("-"),	("-"),	("-"))

smlua_text_utils_course_acts_replace(COURSE_RR, ("15 SECRET STAR HIDE"),	("25 COINS OF THE FLOWERS"),	("25 COINS OF THE SAND"),	("25 COINS OF THE ICE"),	("25 COINS OF THE LAVA"),	("THE HYPERSPEED COINS"),	("-"))

smlua_text_utils_secret_star_replace(15 + 1, ("   BURNING LAVA FORT"))
smlua_text_utils_secret_star_replace(16 + 1, ("   ICY PYRAMID YUKI"))
smlua_text_utils_secret_star_replace(17 + 1, ("   BOWSER'S COLORFUL HEXAGONS"))
smlua_text_utils_secret_star_replace(18 + 1, ("   MOUNTAIN SLIDE"))
smlua_text_utils_secret_star_replace(19 + 1, ("   MAGMATIC TOXIC SEWERS"))
smlua_text_utils_secret_star_replace(20 + 1, ("   WING CAP TOWER"))
smlua_text_utils_secret_star_replace(21 + 1, ("   SEPIA ABANDONED TEMPLE"))
smlua_text_utils_secret_star_replace(22 + 1, ("   WEEGEE"))
smlua_text_utils_secret_star_replace(23 + 1, ("   TEMPLE OF THE SOULLESS STARS"))
smlua_text_utils_secret_star_replace(24 + 1, ("   PEACEFUL PLAINS"))
smlua_text_utils_castle_secret_stars_replace(("   SECRET STARS"))
smlua_text_utils_extra_text_replace(0,("YOU GOT A BONUS STAR"))
smlua_text_utils_extra_text_replace(1,(""))
smlua_text_utils_extra_text_replace(2,(""))
smlua_text_utils_extra_text_replace(3,(""))
smlua_text_utils_extra_text_replace(4,(""))
smlua_text_utils_extra_text_replace(5,(""))
smlua_text_utils_extra_text_replace(6,(""))
