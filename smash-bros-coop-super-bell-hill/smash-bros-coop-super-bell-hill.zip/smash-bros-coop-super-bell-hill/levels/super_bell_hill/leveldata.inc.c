#include "levels/super_bell_hill/area_1/collision.inc.c"
#include "levels/super_bell_hill/area_1/macro.inc.c"
#include "levels/super_bell_hill/area_1/spline.inc.c"
#include "levels/super_bell_hill/model.inc.c"
