const MacroObject super_bell_hill_area_1_macro_objs[] = {
	MACRO_OBJECT_END(),
};

