extern const GeoLayout cloud_platform_geo[];
extern Lights1 Cloud_Platform_Cloud_lights;
extern u8 Cloud_Platform_i4_pyrojay_clouds1_i4[];
extern Vtx Cloud_Platform_Cloud_mesh_layer_1_vtx_cull[8];
extern Vtx Cloud_Platform_Cloud_mesh_layer_1_vtx_0[57];
extern Gfx Cloud_Platform_Cloud_mesh_layer_1_tri_0[];
extern Gfx mat_Cloud_Platform_Cloud[];
extern Gfx Cloud_Platform_Cloud_mesh_layer_1[];
