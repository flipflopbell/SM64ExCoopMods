extern const Collision Cloud_Platform_collision[];
